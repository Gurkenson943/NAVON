# NAVON Programming Language

NAVON ist eine Programmiersprache mit deutscher Syntax, entwickelt von Paul Kaschnitz (PK-Studios).

## Installation

```bash
pip install -e .
```

Für Fenster/Grafik-Unterstützung:
```bash
pip install -e ".[graphics]"
```

## Verwendung

### REPL starten
```bash
python -m navon
```

### .nvn Datei ausführen
```bash
python -m navon datei.nvn
```

## Syntax

### Dateiendung
`.nvn`

### Kommentare
```
?{ Kommentar }
?[ Kommentar an der Seite ]
?/ Mehrzeiliger
   Kommentar /
```

### Variablen
```
set(x): 1;           ?[ x = 1 ]
set(x): "Hello";     ?[ x = "Hello" ]
change(x): + 1;      ?[ x += 1 ]
change(x): - y;      ?[ x -= y ]
change.global(x):    ?[ x wird global ]
```

### Listen
```
set.list(x): { 1, 2, 3 };
set.list(x): { 1, 2 ~ 4 };     ?[ 1 und 2 bis 4 ]
change.list(x): + { 3, 4 };    ?[ Hinzufügen ]
change.list(x): - { y };       ?[ Entfernen ]
```

### Ausgabe
```
give.com(x):                    ?[ x in Konsole ]
give.com("Hallo Welt"):        ?[ String ausgeben ]
give.com("x = <x>"):           ?[ Interpolation ]
give.win("Text"): + [ place(10, 10); color(255, 255, 255); size(25) ];
```

### Funktionen
```
def(addiere): [ add: x, y ]:
    return(x + y);
stop;

set(z): [ function.addiere(2, 3) ];
give.com(z):
>>> 5
```

### Kontrollstrukturen
```
if(x): = 1;
    give.com("x ist 1");
else-if(x): = 2;
    give.com("x ist 2");
else;
    give.com("x ist etwas anderes");
stop;

while(x): < 10;
    change(x): + 1;
stop;

for(i): [1 ~ 10];
    give.com(i);
stop;
```

### Operatoren
| Operator | Bedeutung |
|----------|-----------|
| `+`      | Plus |
| `-`      | Minus |
| `*`      | Mal |
| `/`      | Dividiert |
| `**`     | Potenz |
| `=`      | Ist gleich |
| `>`      | Größer |
| `>=`     | Größer oder gleich |
| `<`      | Kleiner |
| `<=`     | Kleiner oder gleich |
| `n=`     | Nicht gleich |

### Module
```
implement.random;
implement.json;
implement.math;
```

#### Random
```
set(x): [ random.seed(3) ];     ?[ z.B. "734" ]
random.Number(x):               ?[ Zufällige Fließkommazahl ]
random.random(x): [ a, b, c ]   ?[ Zufällige Auswahl ]
```

#### Math
```
set(x): [ math.pi ];            ?[ 3.141592653589793 ]
change(x): [ math.sqrt(25) ];   ?[ 5 ]
```

#### JSON
```
json.save(x): [ "datei.json" ]  ?[ Daten speichern ]
json.load("datei.json"):        ?[ Daten laden ]
```

### Eingabe
```
give.com("Wie heißt du?");
set(name): [ next(input) ];
give.com("Hallo <name>"):
```

### Fenster & Grafik
```
make.windows(
    windows.titel("Mein Spiel");
    windows.color(white);
    windows.size(800, 600);
stop);

depict(box): = [ state(rec); place(100, 100); color(255, 0, 0); size(50, 50) ];
```

### Programm-Einstieg
```
start.programm(
    give.com("Hallo Welt");
stop)
```

### Fehlertypen
- `Syntax-error` — Einrückung oder `;` fehlt
- `Attribute-error` — Attribut oder Methode fehlt
- `Overflow-error` — Zu hohe Zahlen
- `Global-error` — Nicht global
- `Type-error` — Falsch geschrieben
- `Func-error` — Nicht definiert
- `Number-error` — Ungültiger Wert
- `Index-error` — Index außerhalb
- `File-error` — Datei nicht gefunden
- `Key-error` — Schlüssel nicht gefunden
- `Calculation-error` — Rechnung nicht möglich
- `Division-by-0-error` — Division durch 0
- `Intern-error` — Interner Fehler

## Credits

Build by Paul Kaschnitz from PK-Studios
