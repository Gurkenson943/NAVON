"""Built-in modules for NAVON: random, json, math."""

import random as _random
import json as _json
import math as _math
import os


class NavonRandom:
    """NAVON 'random' module."""

    @staticmethod
    def random(args):
        """random.random(x): [ items ] - pick a random item from the list."""
        if isinstance(args, list) and len(args) > 0:
            return _random.choice(args)
        return None

    @staticmethod
    def Number(args):
        """random.Number(x): - random float from a range/set.
           random.Number(<x>): - random integer.
        """
        if isinstance(args, list) and len(args) == 2:
            return _random.uniform(args[0], args[1])
        if isinstance(args, (int, float)):
            return _random.uniform(0, args)
        return _random.random()

    @staticmethod
    def NumberInt(args):
        """Random integer version."""
        if isinstance(args, list) and len(args) == 2:
            return _random.randint(int(args[0]), int(args[1]))
        if isinstance(args, (int, float)):
            return _random.randint(0, int(args))
        return _random.randint(0, 100)

    @staticmethod
    def data(args):
        """random.data(x): [ files ] - pick a random file."""
        if isinstance(args, list) and len(args) > 0:
            return _random.choice(args)
        return None

    @staticmethod
    def seed(length):
        """random.seed(x) - generate a random code of x digits."""
        if isinstance(length, (int, float)):
            length = int(length)
            digits = ''.join([str(_random.randint(0, 9)) for _ in range(length)])
            return digits
        return str(_random.randint(0, 9))

    @staticmethod
    def r():
        """random.r(x): - basic random float 0-1."""
        return _random.random()


class NavonJSON:
    """NAVON 'json' module."""

    @staticmethod
    def save(data, filepath):
        """json.save(x): [ file.json ] - save data to JSON file."""
        dirpath = os.path.dirname(filepath)
        if dirpath and not os.path.exists(dirpath):
            os.makedirs(dirpath, exist_ok=True)
        with open(filepath, 'w', encoding='utf-8') as f:
            _json.dump(data, f, indent=2, ensure_ascii=False)

    @staticmethod
    def load(filepath):
        """json.load(file.json): - load data from JSON file."""
        with open(filepath, 'r', encoding='utf-8') as f:
            return _json.load(f)


class NavonMath:
    """NAVON 'math' module."""

    pi = _math.pi
    e = _math.e

    @staticmethod
    def sqrt(x):
        """math.sqrt(x) - square root."""
        if isinstance(x, (int, float)):
            if x < 0:
                return None
            result = _math.sqrt(x)
            if result == int(result):
                return int(result)
            return result
        return None

    @staticmethod
    def abs(x):
        return abs(x) if isinstance(x, (int, float)) else None

    @staticmethod
    def sin(x):
        return _math.sin(x) if isinstance(x, (int, float)) else None

    @staticmethod
    def cos(x):
        return _math.cos(x) if isinstance(x, (int, float)) else None

    @staticmethod
    def tan(x):
        return _math.tan(x) if isinstance(x, (int, float)) else None

    @staticmethod
    def log(x):
        return _math.log(x) if isinstance(x, (int, float)) and x > 0 else None

    @staticmethod
    def floor(x):
        return _math.floor(x) if isinstance(x, (int, float)) else None

    @staticmethod
    def ceil(x):
        return _math.ceil(x) if isinstance(x, (int, float)) else None
