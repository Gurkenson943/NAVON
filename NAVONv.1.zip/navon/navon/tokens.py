"""Token types for the NAVON lexer."""

from enum import Enum, auto


class TokenType(Enum):
    # Literals
    NUMBER = auto()
    STRING = auto()
    IDENTIFIER = auto()

    # Keywords
    SET = auto()            # set(x): value
    CHANGE = auto()         # change(x): +/- value
    GIVE_COM = auto()       # give.com(x):
    GIVE_WIN = auto()       # give.win(x):
    DEF = auto()            # def(x):
    IF = auto()             # if(x):
    ELSE_IF = auto()        # else-if(x):
    ELSE = auto()           # else:
    WHILE = auto()          # while(x):
    FOR = auto()            # for(x):
    STOP = auto()           # stop
    RETURN = auto()         # return(x)
    BREAK = auto()          # break:
    SET_LIST = auto()       # set.list(x):
    CHANGE_LIST = auto()    # change.list(x):
    CHANGE_GLOBAL = auto()  # change.global(x):
    GLOBAL = auto()         # global.x
    FUNCTION = auto()       # function.x
    IMPLEMENT = auto()      # implement.x
    START_PROGRAMM = auto() # start.programm(
    MAKE_WINDOWS = auto()   # make.windows(
    WINDOWS = auto()        # windows.*
    CLOSE = auto()          # close(x):
    DEPICT = auto()         # depict(x):
    SET_COLOR = auto()      # set.color(x):
    SET_TEXTURE = auto()    # set.texture(x):
    SET_SOUND = auto()      # set.sound(x):
    SET_VIDEO = auto()      # set.video(x):
    SET_FPS = auto()        # set.fps(x):
    LOAD_IMAGE = auto()     # load.image(x):
    LOAD_SOUND = auto()     # load.sound(x):
    LOAD_VIDEO = auto()     # load.video(x):
    FILL = auto()           # fill(x):
    COLLISION = auto()      # collision(x):
    COLLISION_ONLY = auto() # collision.only(x):
    CLEAR = auto()          # clear(x):
    NEXT_INPUT = auto()     # next(input)
    ROUND = auto()          # round(x):
    ROUND_ON = auto()       # round.on(x):
    CLASS = auto()          # class(x):
    INPUT = auto()          # input
    HELP = auto()           # help(true):
    CREDITS = auto()        # credits(true):
    EXIT = auto()           # exit(true):
    UPDATE = auto()         # update()
    KEY = auto()            # key.x

    # Operators
    PLUS = auto()           # +
    MINUS = auto()          # -
    STAR = auto()           # *
    POWER = auto()          # **
    SLASH = auto()          # /
    EQUALS = auto()         # =
    GREATER = auto()        # >
    GREATER_EQ = auto()     # >=
    LESS = auto()           # <
    LESS_EQ = auto()        # <=
    NOT_EQUAL = auto()      # n=

    # Logical
    NOT = auto()            # not
    AND = auto()            # and
    OR = auto()             # or

    # Boolean
    TRUE = auto()           # True
    FALSE = auto()          # False
    PRESSED = auto()        # pressed

    # Delimiters
    LPAREN = auto()         # (
    RPAREN = auto()         # )
    LBRACKET = auto()       # [
    RBRACKET = auto()       # ]
    LBRACE = auto()         # {
    RBRACE = auto()         # }
    COLON = auto()          # :
    SEMICOLON = auto()      # ;
    COMMA = auto()          # ,
    TILDE = auto()          # ~
    DOT = auto()            # .
    ANGLE_LEFT = auto()     # <
    ANGLE_RIGHT = auto()    # >

    # Special
    NEWLINE = auto()
    EOF = auto()

    # Compound keywords (resolved during parsing)
    ADD = auto()            # add:


class Token:
    __slots__ = ('type', 'value', 'line', 'column')

    def __init__(self, type: TokenType, value, line: int = 0, column: int = 0):
        self.type = type
        self.value = value
        self.line = line
        self.column = column

    def __repr__(self):
        return f"Token({self.type}, {self.value!r}, line={self.line})"
