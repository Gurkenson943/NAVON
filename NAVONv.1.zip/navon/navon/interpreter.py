"""Interpreter for the NAVON programming language."""

import sys
import os
from . import ast_nodes as ast
from .errors import (
    NavonError, SyntaxError_, AttributeError_, OverflowError_,
    GlobalError_, TypeError_, FuncError_, NumberError_, IndexError_,
    FileError_, KeyError_, CalculationError_, DivisionByZeroError_,
    InternError_, ReturnSignal, BreakSignal,
)
from .builtins_modules import NavonRandom, NavonJSON, NavonMath


class Environment:
    """Variable environment with scope support."""

    def __init__(self, parent=None):
        self.vars = {}
        self.parent = parent

    def get(self, name):
        if name in self.vars:
            return self.vars[name]
        if self.parent:
            return self.parent.get(name)
        return None

    def set(self, name, value):
        self.vars[name] = value

    def has(self, name):
        if name in self.vars:
            return True
        if self.parent:
            return self.parent.has(name)
        return False

    def update_existing(self, name, value):
        """Update a variable in the scope where it exists."""
        if name in self.vars:
            self.vars[name] = value
            return True
        if self.parent:
            return self.parent.update_existing(name, value)
        return False


class Interpreter:
    def __init__(self, filename="<stdin>"):
        self.filename = filename
        self.global_env = Environment()
        self.functions = {}
        self.global_functions = set()
        self.classes = {}
        self.modules = {}
        self.colors = {
            'black': (0, 0, 0),
            'white': (255, 255, 255),
            'red': (255, 0, 0),
            'green': (0, 255, 0),
            'blue': (0, 0, 255),
            'yellow': (255, 255, 0),
            'cyan': (0, 255, 255),
            'magenta': (255, 0, 255),
        }
        self.textures = {}
        self.sounds = {}
        self.depictions = {}
        self.last_error = None

        # Window state
        self.window = None
        self.window_settings = {}
        self.bg_color = (0, 0, 0)
        self.fps = 60
        self.pygame_initialized = False

    def run(self, program):
        """Run a parsed NAVON program."""
        if isinstance(program, ast.Program):
            self.execute_statements(program.statements, self.global_env)
        else:
            self.execute_node(program, self.global_env)

    def execute_statements(self, statements, env):
        """Execute a list of statements."""
        for stmt in statements:
            self.execute_node(stmt, env)

    def execute_node(self, node, env):
        """Execute a single AST node."""
        if node is None:
            return None

        if isinstance(node, ast.SetVariable):
            return self.exec_set(node, env)
        elif isinstance(node, ast.SetList):
            return self.exec_set_list(node, env)
        elif isinstance(node, ast.ChangeVariable):
            return self.exec_change(node, env)
        elif isinstance(node, ast.ChangeWithExpr):
            return self.exec_change_with_expr(node, env)
        elif isinstance(node, ast.ChangeGlobal):
            return self.exec_change_global(node, env)
        elif isinstance(node, ast.ChangeList):
            return self.exec_change_list(node, env)
        elif isinstance(node, ast.GiveCom):
            return self.exec_give_com(node, env)
        elif isinstance(node, ast.GiveWin):
            return self.exec_give_win(node, env)
        elif isinstance(node, ast.FunctionDef):
            return self.exec_function_def(node, env)
        elif isinstance(node, ast.FunctionCall):
            return self.exec_function_call(node, env)
        elif isinstance(node, ast.GlobalDecl):
            return self.exec_global_decl(node, env)
        elif isinstance(node, ast.ReturnStatement):
            value = self.evaluate(node.value, env)
            raise ReturnSignal(value)
        elif isinstance(node, ast.BreakStatement):
            raise BreakSignal()
        elif isinstance(node, ast.IfStatement):
            return self.exec_if(node, env)
        elif isinstance(node, ast.WhileStatement):
            return self.exec_while(node, env)
        elif isinstance(node, ast.ForStatement):
            return self.exec_for(node, env)
        elif isinstance(node, ast.StartProgramm):
            return self.exec_start_programm(node, env)
        elif isinstance(node, ast.ImplementStatement):
            return self.exec_implement(node, env)
        elif isinstance(node, ast.MakeWindows):
            return self.exec_make_windows(node, env)
        elif isinstance(node, ast.DepictStatement):
            return self.exec_depict(node, env)
        elif isinstance(node, ast.SetColorDef):
            return self.exec_set_color(node, env)
        elif isinstance(node, ast.SetTexture):
            return self.exec_set_texture(node, env)
        elif isinstance(node, ast.SetFps):
            return self.exec_set_fps(node, env)
        elif isinstance(node, ast.FillStatement):
            return self.exec_fill(node, env)
        elif isinstance(node, ast.ClearStatement):
            return self.exec_clear(node, env)
        elif isinstance(node, ast.CloseStatement):
            return self.exec_close(node, env)
        elif isinstance(node, ast.ClassDef):
            return self.exec_class_def(node, env)
        elif isinstance(node, ast.LoadImage):
            return self.exec_load_image(node, env)
        else:
            # Try to evaluate as expression
            return self.evaluate(node, env)

    def evaluate(self, node, env):
        """Evaluate an expression node and return its value."""
        if node is None:
            return None

        if isinstance(node, ast.NumberLiteral):
            return node.value

        if isinstance(node, ast.StringLiteral):
            return node.value

        if isinstance(node, ast.BooleanLiteral):
            return node.value

        if isinstance(node, ast.Identifier):
            val = env.get(node.name)
            if val is None and not env.has(node.name):
                # Check global env
                val = self.global_env.get(node.name)
                if val is None and not self.global_env.has(node.name):
                    raise FuncError_(node.name, self.filename)
            return val

        if isinstance(node, ast.InterpolatedString):
            parts = []
            for part in node.parts:
                if isinstance(part, str):
                    parts.append(part)
                elif isinstance(part, ast.Identifier):
                    val = env.get(part.name)
                    if val is None:
                        val = self.global_env.get(part.name)
                    parts.append(self.format_value(val))
                else:
                    parts.append(self.format_value(self.evaluate(part, env)))
            return ''.join(parts)

        if isinstance(node, ast.BinaryOp):
            left = self.evaluate(node.left, env)
            right = self.evaluate(node.right, env)
            return self.eval_binary_op(node.op, left, right)

        if isinstance(node, ast.UnaryOp):
            operand = self.evaluate(node.operand, env)
            if node.op == '-':
                return -operand
            return operand

        if isinstance(node, ast.Comparison):
            left = self.evaluate(node.left, env)
            right = self.evaluate(node.right, env)
            return self.eval_comparison(node.op, left, right)

        if isinstance(node, ast.LogicalOp):
            left = self.evaluate(node.left, env)
            if node.op == 'and':
                if not left:
                    return False
                return bool(self.evaluate(node.right, env))
            elif node.op == 'or':
                if left:
                    return True
                return bool(self.evaluate(node.right, env))

        if isinstance(node, ast.NotOp):
            return not self.evaluate(node.operand, env)

        if isinstance(node, ast.FunctionCall):
            return self.exec_function_call(node, env)

        if isinstance(node, ast.ModuleCall):
            return self.exec_module_call(node, env)

        if isinstance(node, ast.NextInput):
            return input()

        if isinstance(node, ast.RoundExpr):
            val = self.evaluate(node.value, env)
            return round(val)

        if isinstance(node, ast.RoundOnExpr):
            val = self.evaluate(node.value, env)
            decimals = int(self.evaluate(node.decimals, env))
            return round(val, decimals)

        if isinstance(node, ast.KeyCheck):
            return self.check_key(node.key_name)

        if isinstance(node, ast.LoadImage):
            return node.filename

        if isinstance(node, ast.ListBracketExpr):
            return self.evaluate(node.expr, env)

        if isinstance(node, ast.RangeExpr):
            start = self.evaluate(node.start, env)
            end = self.evaluate(node.end, env)
            return list(range(int(start), int(end) + 1))

        raise InternError_(f"Cannot evaluate node: {type(node).__name__}", self.filename)

    def eval_binary_op(self, op, left, right):
        """Evaluate a binary operation."""
        # Handle string concatenation
        if op == '+' and (isinstance(left, str) or isinstance(right, str)):
            return self.format_value(left) + self.format_value(right)

        if not isinstance(left, (int, float)) or not isinstance(right, (int, float)):
            if op == '+':
                return str(left) + str(right)
            raise TypeError_(f"Cannot apply {op} to {type(left).__name__} and {type(right).__name__}", filename=self.filename)

        if op == '+':
            return left + right
        elif op == '-':
            return left - right
        elif op == '*':
            result = left * right
            if abs(result) > 1e308:
                raise OverflowError_(filename=self.filename)
            return result
        elif op == '/':
            if right == 0:
                raise DivisionByZeroError_(self.filename)
            result = left / right
            if result == int(result):
                return int(result)
            return result
        elif op == '**':
            try:
                result = left ** right
                if isinstance(result, (int, float)) and abs(result) > 1e308:
                    raise OverflowError_(filename=self.filename)
                return result
            except OverflowError:
                raise OverflowError_(filename=self.filename)
        raise CalculationError_(f"{left} {op} {right}", self.filename)

    def eval_comparison(self, op, left, right):
        """Evaluate a comparison operation."""
        if op == '=':
            return left == right
        elif op == '>':
            return left > right
        elif op == '>=':
            return left >= right
        elif op == '<':
            return left < right
        elif op == '<=':
            return left <= right
        elif op == 'n=':
            return left != right
        raise CalculationError_(f"Unknown comparison: {op}", self.filename)

    def exec_set(self, node, env):
        """Execute set(name): value"""
        value = self.evaluate(node.value, env)
        env.set(node.name, value)
        return value

    def exec_set_list(self, node, env):
        """Execute set.list(name): { elements }"""
        elements = []
        for elem in node.elements:
            if isinstance(elem, ast.RangeExpr):
                start = self.evaluate(elem.start, env)
                end = self.evaluate(elem.end, env)
                # "alle zahlen" - all numbers including floats represented as range
                elements.append(('range', start, end))
            else:
                elements.append(self.evaluate(elem, env))
        env.set(node.name, elements)

    def exec_change(self, node, env):
        """Execute change(name): op value"""
        current = env.get(node.name)
        if current is None:
            current = self.global_env.get(node.name)
        if current is None and node.op != '=':
            raise FuncError_(node.name, self.filename)

        val = self.evaluate(node.value, env)

        if node.second_value is not None:
            val2 = self.evaluate(node.second_value, env)
            val = self.eval_binary_op(node.op, val, val2)
            if not env.update_existing(node.name, val):
                self.global_env.set(node.name, val)
            return

        if node.op == '=':
            if not env.update_existing(node.name, val):
                env.set(node.name, val)
        elif node.op == '+':
            result = self.eval_binary_op('+', current, val)
            if not env.update_existing(node.name, result):
                self.global_env.set(node.name, result)
        elif node.op == '-':
            result = self.eval_binary_op('-', current, val)
            if not env.update_existing(node.name, result):
                self.global_env.set(node.name, result)
        elif node.op == '*':
            result = self.eval_binary_op('*', current, val)
            if not env.update_existing(node.name, result):
                self.global_env.set(node.name, result)
        elif node.op == '/':
            result = self.eval_binary_op('/', current, val)
            if not env.update_existing(node.name, result):
                self.global_env.set(node.name, result)
        elif node.op == '**':
            result = self.eval_binary_op('**', current, val)
            if not env.update_existing(node.name, result):
                self.global_env.set(node.name, result)

    def exec_change_with_expr(self, node, env):
        """Execute change(name): [ expr ]"""
        val = self.evaluate(node.expr, env)
        if not env.update_existing(node.name, val):
            self.global_env.set(node.name, val)

    def exec_change_global(self, node, env):
        """Execute change.global(name):"""
        val = env.get(node.name)
        if val is not None:
            self.global_env.set(node.name, val)

    def exec_change_list(self, node, env):
        """Execute change.list(name): +/- { elements }"""
        lst = env.get(node.name)
        if lst is None:
            lst = self.global_env.get(node.name)
        if lst is None:
            raise FuncError_(node.name, self.filename)

        if not isinstance(lst, list):
            raise TypeError_("Expected a list", filename=self.filename)

        for elem in node.elements:
            val = self.evaluate(elem, env)
            if node.op == '+':
                lst.append(val)
            elif node.op == '-':
                if val in lst:
                    lst.remove(val)

    def exec_give_com(self, node, env):
        """Execute give.com(expr): - print to console."""
        val = self.evaluate(node.expr, env)
        print(self.format_value(val))

    def exec_give_win(self, node, env):
        """Execute give.win(expr): - display in window."""
        val = self.evaluate(node.expr, env)
        if self.window and self.pygame_initialized:
            self._render_text_in_window(val, node.options, env)
        else:
            # Fallback to console
            print(f"[Window] {self.format_value(val)}")

    def exec_function_def(self, node, env):
        """Execute def(name): define a function."""
        self.functions[node.name] = node

    def exec_function_call(self, node, env):
        """Execute function.name or name(args)."""
        name = node.name
        func_def = self.functions.get(name)

        if func_def is None:
            raise FuncError_(name, self.filename)

        # Create new scope
        func_env = Environment(self.global_env)

        # Bind parameters
        for i, param in enumerate(func_def.params):
            if i < len(node.args):
                val = self.evaluate(node.args[i], env)
                func_env.set(param, val)

        # Copy non-global vars from current env if the function is global
        if name in self.global_functions:
            for k, v in self.global_env.vars.items():
                if k not in func_env.vars:
                    func_env.set(k, v)

        try:
            self.execute_statements(func_def.body, func_env)
        except ReturnSignal as ret:
            return ret.value

        # Sync back global vars
        for k, v in func_env.vars.items():
            if self.global_env.has(k):
                self.global_env.set(k, v)

        return None

    def exec_global_decl(self, node, env):
        """Execute global.name"""
        self.global_functions.add(node.name)

    def exec_if(self, node, env):
        """Execute if/else-if/else."""
        cond = self.evaluate(node.condition, env)
        if cond:
            self.execute_statements(node.body, env)
            return

        for elif_cond, elif_body in node.elif_clauses:
            cond = self.evaluate(elif_cond, env)
            if cond:
                self.execute_statements(elif_body, env)
                return

        if node.else_body:
            self.execute_statements(node.else_body, env)

    def exec_while(self, node, env):
        """Execute while loop."""
        max_iter = 10_000_000
        count = 0
        while True:
            # Pump pygame events to keep window responsive
            if self.pygame_initialized:
                self.pump_pygame_events()
                if not self.pygame_initialized:
                    break
            cond = self.evaluate(node.condition, env)
            if not cond:
                break
            try:
                self.execute_statements(node.body, env)
            except BreakSignal:
                break
            count += 1
            if count > max_iter:
                raise OverflowError_("Infinite loop detected", self.filename)
            # Frame rate limiting when pygame is active
            if self.pygame_initialized:
                try:
                    import pygame
                    pygame.time.Clock().tick(self.fps)
                except ImportError:
                    pass

    def exec_for(self, node, env):
        """Execute for loop."""
        start = self.evaluate(node.range_expr.start, env)
        end = self.evaluate(node.range_expr.end, env)
        for i in range(int(start), int(end) + 1):
            env.set(node.var_name, i)
            try:
                self.execute_statements(node.body, env)
            except BreakSignal:
                break

    def exec_start_programm(self, node, env):
        """Execute start.programm( body stop)"""
        self.execute_statements(node.body, env)

    def exec_implement(self, node, env):
        """Execute implement.module"""
        name = node.module_name
        if name == 'random':
            self.modules['random'] = NavonRandom()
        elif name == 'json':
            self.modules['json'] = NavonJSON()
        elif name == 'math':
            self.modules['math'] = NavonMath()
        else:
            # Try to load from file
            filepath = name
            if not filepath.endswith('.nvn'):
                filepath += '.nvn'
            if os.path.exists(filepath):
                from .lexer import Lexer
                from .parser import Parser
                with open(filepath, 'r', encoding='utf-8') as f:
                    source = f.read()
                lexer = Lexer(source, filepath)
                tokens = lexer.tokenize()
                parser = Parser(tokens, filepath)
                program = parser.parse()
                self.execute_statements(program.statements, env)
            else:
                raise FileError_(f"Module '{name}' not found", self.filename)

    def exec_module_call(self, node, env):
        """Execute a module method call."""
        module_name = node.module
        method_name = node.method

        # Evaluate args
        args = [self.evaluate(a, env) for a in node.args]

        if module_name == 'random':
            mod = self.modules.get('random')
            if mod is None:
                raise FuncError_("random (not implemented, use: implement.random)", self.filename)
            if method_name == 'random':
                return mod.random(args)
            elif method_name == 'Number':
                return mod.Number(args if len(args) > 1 else (args[0] if args else None))
            elif method_name == 'seed':
                return mod.seed(args[0] if args else 3)
            elif method_name == 'data':
                return mod.data(args)
            elif method_name == 'r':
                return mod.r()
            else:
                raise AttributeError_(f"random.{method_name}", self.filename)

        elif module_name == 'json':
            mod = self.modules.get('json')
            if mod is None:
                raise FuncError_("json (not implemented, use: implement.json)", self.filename)
            if method_name == 'save':
                if len(args) >= 2:
                    mod.save(args[0], args[1])
                return None
            elif method_name == 'load':
                if args:
                    return mod.load(args[0])
                return None
            else:
                raise AttributeError_(f"json.{method_name}", self.filename)

        elif module_name == 'math':
            mod = self.modules.get('math')
            if mod is None:
                raise FuncError_("math (not implemented, use: implement.math)", self.filename)
            if method_name == 'pi':
                return NavonMath.pi
            elif method_name == 'e':
                return NavonMath.e
            elif method_name == 'sqrt':
                return NavonMath.sqrt(args[0] if args else 0)
            elif method_name == 'abs':
                return NavonMath.abs(args[0] if args else 0)
            elif method_name == 'sin':
                return NavonMath.sin(args[0] if args else 0)
            elif method_name == 'cos':
                return NavonMath.cos(args[0] if args else 0)
            elif method_name == 'tan':
                return NavonMath.tan(args[0] if args else 0)
            elif method_name == 'log':
                return NavonMath.log(args[0] if args else 1)
            elif method_name == 'floor':
                return NavonMath.floor(args[0] if args else 0)
            elif method_name == 'ceil':
                return NavonMath.ceil(args[0] if args else 0)
            else:
                raise AttributeError_(f"math.{method_name}", self.filename)

        # Check if it's a constant access like math.pi
        if module_name == 'math' and method_name in ('pi', 'e'):
            return getattr(NavonMath, method_name)

        raise FuncError_(f"{module_name}.{method_name}", self.filename)

    # Known keywords that should be treated as string literals in graphics contexts
    _GRAPHICS_KEYWORDS = {
        'white', 'black', 'red', 'green', 'blue', 'yellow', 'cyan', 'magenta',
        'full', 'zoomed',
        'rec', 'cir', 'line', 'button',
        'ground', 'text', 'all', 'windows',
    }

    def evaluate_soft(self, node, env):
        """Evaluate an expression, but treat unknown identifiers as string literals
        if they match known graphics/window keywords or color names."""
        if isinstance(node, ast.Identifier):
            # First try as variable
            if env.has(node.name) or self.global_env.has(node.name):
                return self.evaluate(node, env)
            # Then check known keywords and colors
            if node.name in self._GRAPHICS_KEYWORDS or node.name in self.colors:
                return node.name
            # Fall back to returning the name as a string
            return node.name
        if isinstance(node, ast.ASTNode):
            return self.evaluate(node, env)
        return node

    def exec_make_windows(self, node, env):
        """Create a window using pygame."""
        settings = {}
        for key, args in node.settings.items():
            vals = [self.evaluate_soft(a, env) for a in args]
            settings[key] = vals

        self.window_settings = settings
        self._init_pygame_window(settings, env)

    def exec_depict(self, node, env):
        """Execute depict(name): [ options ]"""
        options = {}
        for key, args in node.options.items():
            vals = [self.evaluate_soft(a, env) for a in args]
            options[key] = vals
        self.depictions[node.name] = options

        if self.pygame_initialized:
            self._draw_depiction(node.name, options, env)

    def exec_set_color(self, node, env):
        """Execute set.color(name): [ r, g, b ]"""
        r = self.evaluate(node.rgb[0], env)
        g = self.evaluate(node.rgb[1], env)
        b = self.evaluate(node.rgb[2], env)
        self.colors[node.name] = (int(r), int(g), int(b))

    def exec_set_texture(self, node, env):
        """Execute set.texture(name): [ load_expr ]"""
        val = self.evaluate(node.load_expr, env)
        self.textures[node.name] = val

    def exec_set_fps(self, node, env):
        """Execute set.fps(value):"""
        self.fps = int(self.evaluate(node.value, env))

    def exec_fill(self, node, env):
        """Execute fill(name): = [ color ]"""
        color = self.evaluate_soft(node.color, env)
        if isinstance(color, str):
            color = self.colors.get(color, (255, 255, 255))
        self.depictions.setdefault(node.name, {})['fill'] = color

    def exec_clear(self, node, env):
        """Execute clear(target):"""
        if node.target == 'all':
            self.depictions.clear()
        elif node.target == 'text':
            # Clear text depictions
            to_remove = [k for k, v in self.depictions.items() if 'text' in v]
            for k in to_remove:
                del self.depictions[k]
        elif node.target in self.depictions:
            del self.depictions[node.target]

    def exec_close(self, node, env):
        """Execute close(target):"""
        if node.target == 'windows' and self.pygame_initialized:
            try:
                import pygame
                pygame.quit()
                self.pygame_initialized = False
                self.window = None
            except ImportError:
                pass

    def exec_class_def(self, node, env):
        """Execute class(name): body stop;"""
        self.classes[node.name] = node.body

    def exec_load_image(self, node, env):
        """Execute load.image(filename):"""
        return node.filename

    def format_value(self, val):
        """Format a value for output."""
        if val is None:
            return "None"
        if isinstance(val, bool):
            return "True" if val else "False"
        if isinstance(val, float):
            if val == int(val):
                return str(int(val))
            return str(val)
        if isinstance(val, list):
            return str(val)
        return str(val)

    def pump_pygame_events(self):
        """Process pygame events (required for key detection and window updates)."""
        if not self.pygame_initialized:
            return
        try:
            import pygame
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    self.pygame_initialized = False
                    self.window = None
        except ImportError:
            pass

    def check_key(self, key_name):
        """Check if a key is pressed (requires pygame)."""
        if not self.pygame_initialized:
            return False
        try:
            import pygame
            # Must pump events first so key states are updated
            self.pump_pygame_events()
            if not self.pygame_initialized:
                return False
            keys = pygame.key.get_pressed()
            key_map = {
                'esc': pygame.K_ESCAPE,
                'space': pygame.K_SPACE,
                'up': pygame.K_UP,
                'down': pygame.K_DOWN,
                'left': pygame.K_LEFT,
                'right': pygame.K_RIGHT,
                'enter': pygame.K_RETURN,
                'tab': pygame.K_TAB,
                'backspace': pygame.K_BACKSPACE,
                'delete': pygame.K_DELETE,
            }
            # Single letter keys
            if len(key_name) == 1 and key_name.isalpha():
                return keys[getattr(pygame, f'K_{key_name.lower()}', 0)]
            # Number keys
            if len(key_name) == 1 and key_name.isdigit():
                return keys[getattr(pygame, f'K_{key_name}', 0)]
            if key_name in key_map:
                return keys[key_map[key_name]]
            # Mouse buttons
            if key_name == 'mleft':
                return pygame.mouse.get_pressed()[0]
            if key_name == 'mright':
                return pygame.mouse.get_pressed()[2]
            if key_name == 'mroll':
                return False  # scroll handled via events
            return False
        except ImportError:
            return False

    def _init_pygame_window(self, settings, env):
        """Initialize a pygame window."""
        try:
            import pygame
            pygame.init()
            self.pygame_initialized = True

            title = "NAVON"
            bg_color = (0, 0, 0)
            size = (800, 600)

            if 'titel' in settings:
                title = str(settings['titel'][0])
            if 'color' in settings:
                c = settings['color'][0]
                if isinstance(c, str):
                    bg_color = self.colors.get(c, (0, 0, 0))
                elif isinstance(c, tuple):
                    bg_color = c
            if 'size' in settings:
                vals = settings['size']
                if len(vals) == 1:
                    s = vals[0]
                    if isinstance(s, str):
                        if s == 'full':
                            size = (0, 0)  # fullscreen
                        elif s == 'zoomed':
                            info = pygame.display.Info()
                            size = (info.current_w, info.current_h)
                    else:
                        size = (int(s), int(s))
                elif len(vals) == 2:
                    size = (int(vals[0]), int(vals[1]))

            if size == (0, 0):
                self.window = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
            else:
                self.window = pygame.display.set_mode(size)

            pygame.display.set_caption(title)
            self.bg_color = bg_color
            self.window.fill(self.bg_color)
            pygame.display.flip()
        except ImportError:
            print("[NAVON] Warning: pygame not available. Window features disabled.")
            self.pygame_initialized = False

    def redraw_all(self):
        """Redraw the entire window: fill background, then redraw all depictions."""
        if not self.pygame_initialized or not self.window:
            return
        try:
            import pygame
            self.window.fill(self.bg_color)
            for dep_name, dep_options in self.depictions.items():
                self._draw_single(dep_name, dep_options)
            pygame.display.flip()
        except ImportError:
            pass

    def _draw_depiction(self, name, options, env):
        """Draw a shape/element on the pygame window."""
        if not self.pygame_initialized or not self.window:
            return
        self._draw_single(name, options)
        try:
            import pygame
            pygame.display.flip()
        except ImportError:
            pass

    def _draw_single(self, name, options):
        """Draw a single shape without flipping the display."""
        if not self.pygame_initialized or not self.window:
            return
        try:
            import pygame

            state = None
            place = (0, 0)
            color = (255, 255, 255)
            size = (50, 50)
            text_str = None
            text_color = (0, 0, 0)

            for key, vals in options.items():
                if key == 'state':
                    state = vals[0] if vals else None
                elif key == 'place':
                    place = (int(vals[0]), int(vals[1])) if len(vals) >= 2 else (0, 0)
                elif key == 'color':
                    if len(vals) == 3:
                        color = (int(vals[0]), int(vals[1]), int(vals[2]))
                    elif len(vals) == 1 and isinstance(vals[0], str):
                        color = self.colors.get(vals[0], (255, 255, 255))
                elif key == 'size':
                    if len(vals) == 2:
                        size = (int(vals[0]), int(vals[1]))
                    elif len(vals) == 1:
                        size = (int(vals[0]), int(vals[0]))
                elif key == 'text':
                    text_str = str(vals[0]) if vals else None
                elif key == 'text.co':
                    if len(vals) == 3:
                        text_color = (int(vals[0]), int(vals[1]), int(vals[2]))
                    elif len(vals) == 1 and isinstance(vals[0], str):
                        text_color = self.colors.get(vals[0], (0, 0, 0))

            if isinstance(state, str):
                if state == 'rec':
                    pygame.draw.rect(self.window, color, (*place, *size))
                elif state == 'cir':
                    radius = size[0] if isinstance(size, tuple) else size
                    pygame.draw.circle(self.window, color, place, int(radius))
                elif state == 'line':
                    end = size if isinstance(size, tuple) else (place[0] + size, place[1])
                    pygame.draw.line(self.window, color, place, end, 2)
                elif state == 'button':
                    pygame.draw.rect(self.window, color, (*place, *size))
                    if text_str:
                        font = pygame.font.Font(None, min(size[0], size[1]) // 2)
                        text_surf = font.render(text_str, True, text_color)
                        text_rect = text_surf.get_rect(center=(place[0] + size[0] // 2, place[1] + size[1] // 2))
                        self.window.blit(text_surf, text_rect)

            # Handle texture
            if name in self.textures:
                tex_file = self.textures[name]
                if os.path.exists(tex_file):
                    img = pygame.image.load(tex_file)
                    img = pygame.transform.scale(img, size)
                    self.window.blit(img, place)
        except ImportError:
            pass

    def _render_text_in_window(self, text, options, env):
        """Render text in the pygame window."""
        if not self.pygame_initialized or not self.window:
            return
        try:
            import pygame
            place = (10, 10)
            color = (255, 255, 255)
            font_size = 24

            if options:
                if 'place' in options:
                    vals = options['place']
                    evaluated = [self.evaluate_soft(v, env) for v in vals]
                    place = (int(evaluated[0]), int(evaluated[1]))
                if 'color' in options:
                    vals = options['color']
                    evaluated = [self.evaluate_soft(v, env) for v in vals]
                    if len(evaluated) == 3:
                        color = (int(evaluated[0]), int(evaluated[1]), int(evaluated[2]))
                    elif len(evaluated) == 1 and isinstance(evaluated[0], str):
                        color = self.colors.get(evaluated[0], (255, 255, 255))
                if 'size' in options:
                    vals = options['size']
                    evaluated = [self.evaluate_soft(v, env) for v in vals]
                    font_size = int(evaluated[0])

            font = pygame.font.Font(None, font_size)
            text_surf = font.render(str(text), True, color)
            self.window.blit(text_surf, place)
            pygame.display.flip()
        except ImportError:
            print(f"[Window] {text}")
