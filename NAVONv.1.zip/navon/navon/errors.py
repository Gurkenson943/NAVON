"""Error types for the NAVON programming language."""


class NavonError(Exception):
    """Base error for all NAVON runtime errors."""
    def __init__(self, error_type, message, filename="<stdin>", line=0):
        self.error_type = error_type
        self.filename = filename
        self.line = line
        self.message = message
        super().__init__(self.format())

    def format(self):
        return (
            f"\nTraceback (most recent call):\n"
            f"  File \"{self.filename}\", line {self.line}, in <module>\n"
            f"{self.error_type}: {self.message}"
        )


class SyntaxError_(NavonError):
    def __init__(self, message, filename="<stdin>", line=0):
        super().__init__("Syntax-error", message, filename, line)


class AttributeError_(NavonError):
    def __init__(self, attr, filename="<stdin>", line=0):
        super().__init__("Attribute-error", f"({attr} is missing)", filename, line)


class OverflowError_(NavonError):
    def __init__(self, message="Number too large", filename="<stdin>", line=0):
        super().__init__("Overflow-error", message, filename, line)


class GlobalError_(NavonError):
    def __init__(self, name, filename="<stdin>", line=0):
        super().__init__("Global-error", f"({name} is not global)", filename, line)


class TypeError_(NavonError):
    def __init__(self, wrong, suggestion=None, filename="<stdin>", line=0):
        if suggestion:
            msg = f"({wrong} did you mean {suggestion})"
        else:
            msg = wrong
        super().__init__("Type-error", msg, filename, line)


class FuncError_(NavonError):
    def __init__(self, name, filename="<stdin>", line=0):
        super().__init__("Func-error", f"({name} is not defined)", filename, line)


class NumberError_(NavonError):
    def __init__(self, message="Invalid number value", filename="<stdin>", line=0):
        super().__init__("Number-error", message, filename, line)


class IndexError_(NavonError):
    def __init__(self, message="Index out of range", filename="<stdin>", line=0):
        super().__init__("Index-error", message, filename, line)


class FileError_(NavonError):
    def __init__(self, message="File not found or unreadable", filename="<stdin>", line=0):
        super().__init__("File-error", message, filename, line)


class KeyError_(NavonError):
    def __init__(self, key, filename="<stdin>", line=0):
        super().__init__("Key-error", f"Key '{key}' not found", filename, line)


class CalculationError_(NavonError):
    def __init__(self, calc, filename="<stdin>", line=0):
        super().__init__("Calculation-error", f"({calc} is not possible)", filename, line)


class DivisionByZeroError_(NavonError):
    def __init__(self, filename="<stdin>", line=0):
        super().__init__("Division-by-0-error", "Division by zero", filename, line)


class InternError_(NavonError):
    def __init__(self, message="Internal error", filename="<stdin>", line=0):
        super().__init__("Intern-error", message, filename, line)


class ReturnSignal(Exception):
    """Used to propagate return values through the call stack."""
    def __init__(self, value):
        self.value = value


class BreakSignal(Exception):
    """Used to break out of loops."""
    pass
