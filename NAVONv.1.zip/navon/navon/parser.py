"""Parser for the NAVON programming language."""

from .tokens import Token, TokenType
from . import ast_nodes as ast


class ParseError(Exception):
    def __init__(self, message, token=None):
        self.token = token
        line = token.line if token else '?'
        super().__init__(f"Syntax-error at line {line}: {message}")


class Parser:
    def __init__(self, tokens, filename="<stdin>"):
        self.tokens = [t for t in tokens if t.type != TokenType.NEWLINE]
        self.pos = 0
        self.filename = filename

    def peek(self, offset=0):
        p = self.pos + offset
        if p < len(self.tokens):
            return self.tokens[p]
        return Token(TokenType.EOF, None)

    def current(self):
        return self.peek(0)

    def advance(self):
        tok = self.tokens[self.pos]
        self.pos += 1
        return tok

    def expect(self, token_type, value=None):
        tok = self.current()
        if tok.type != token_type:
            raise ParseError(f"Expected {token_type}, got {tok.type} ({tok.value!r})", tok)
        if value is not None and tok.value != value:
            raise ParseError(f"Expected {value!r}, got {tok.value!r}", tok)
        return self.advance()

    def match(self, *types):
        if self.current().type in types:
            return self.advance()
        return None

    def match_value(self, token_type, value):
        tok = self.current()
        if tok.type == token_type and tok.value == value:
            return self.advance()
        return None

    def at_end(self):
        return self.current().type == TokenType.EOF

    def skip_semicolons(self):
        while self.match(TokenType.SEMICOLON):
            pass

    def parse(self):
        stmts = self.parse_statements()
        return ast.Program(stmts)

    def parse_statements(self, stop_tokens=None):
        """Parse a list of statements until EOF or a stop token is reached."""
        if stop_tokens is None:
            stop_tokens = set()
        statements = []
        while not self.at_end():
            self.skip_semicolons()
            if self.at_end():
                break
            tok = self.current()
            if tok.type == TokenType.STOP:
                break
            if tok.type in stop_tokens:
                break
            stmt = self.parse_statement()
            if stmt is not None:
                statements.append(stmt)
            self.skip_semicolons()
        return statements

    def parse_statement(self):
        tok = self.current()

        if tok.type == TokenType.SET:
            return self.parse_set()
        elif tok.type == TokenType.SET_LIST:
            return self.parse_set_list()
        elif tok.type == TokenType.CHANGE:
            return self.parse_change()
        elif tok.type == TokenType.CHANGE_GLOBAL:
            return self.parse_change_global()
        elif tok.type == TokenType.CHANGE_LIST:
            return self.parse_change_list()
        elif tok.type == TokenType.GIVE_COM:
            return self.parse_give_com()
        elif tok.type == TokenType.GIVE_WIN:
            return self.parse_give_win()
        elif tok.type == TokenType.DEF:
            return self.parse_def()
        elif tok.type == TokenType.IF:
            return self.parse_if()
        elif tok.type == TokenType.WHILE:
            return self.parse_while()
        elif tok.type == TokenType.FOR:
            return self.parse_for()
        elif tok.type == TokenType.RETURN:
            return self.parse_return()
        elif tok.type == TokenType.BREAK:
            self.advance()
            self.match(TokenType.COLON)
            return ast.BreakStatement()
        elif tok.type == TokenType.GLOBAL:
            return self.parse_global_decl()
        elif tok.type == TokenType.FUNCTION:
            return self.parse_function_call_stmt()
        elif tok.type == TokenType.IMPLEMENT:
            return self.parse_implement()
        elif tok.type == TokenType.START_PROGRAMM:
            return self.parse_start_programm()
        elif tok.type == TokenType.MAKE_WINDOWS:
            return self.parse_make_windows()
        elif tok.type == TokenType.DEPICT:
            return self.parse_depict()
        elif tok.type == TokenType.SET_COLOR:
            return self.parse_set_color()
        elif tok.type == TokenType.SET_TEXTURE:
            return self.parse_set_texture()
        elif tok.type == TokenType.SET_FPS:
            return self.parse_set_fps()
        elif tok.type == TokenType.LOAD_IMAGE:
            return self.parse_load_image()
        elif tok.type == TokenType.FILL:
            return self.parse_fill()
        elif tok.type == TokenType.CLEAR:
            return self.parse_clear()
        elif tok.type == TokenType.CLOSE:
            return self.parse_close()
        elif tok.type == TokenType.CLASS:
            return self.parse_class()
        elif tok.type == TokenType.IDENTIFIER:
            # Could be a function call like function.name or just an expression
            return self.parse_expression_statement()
        elif tok.type == TokenType.STOP:
            return None
        else:
            raise ParseError(f"Unexpected token: {tok.type} ({tok.value!r})", tok)

    def parse_set(self):
        """Parse: set(name): value"""
        self.advance()  # set
        self.expect(TokenType.LPAREN)
        name = self.expect(TokenType.IDENTIFIER).value
        self.expect(TokenType.RPAREN)
        self.expect(TokenType.COLON)

        # Check for bracket expression: set(z): [ function.x(2, 3) ];
        if self.current().type == TokenType.LBRACKET:
            self.advance()  # [
            value = self.parse_expression()
            self.expect(TokenType.RBRACKET)
        else:
            value = self.parse_expression()

        return ast.SetVariable(name, value)

    def parse_set_list(self):
        """Parse: set.list(name): { elements }"""
        self.advance()  # set.list
        self.expect(TokenType.LPAREN)
        name = self.expect(TokenType.IDENTIFIER).value
        self.expect(TokenType.RPAREN)
        self.expect(TokenType.COLON)
        self.expect(TokenType.LBRACE)

        elements = self.parse_list_elements()

        self.expect(TokenType.RBRACE)
        return ast.SetList(name, elements)

    def parse_list_elements(self):
        """Parse list elements, handling ranges with ~."""
        elements = []
        while self.current().type != TokenType.RBRACE and not self.at_end():
            expr = self.parse_expression()
            if self.current().type == TokenType.TILDE:
                self.advance()  # ~
                end = self.parse_expression()
                elements.append(ast.RangeExpr(expr, end))
            else:
                elements.append(expr)
            if not self.match(TokenType.COMMA):
                break
        return elements

    def parse_change(self):
        """Parse: change(name): op value"""
        self.advance()  # change
        self.expect(TokenType.LPAREN)
        name = self.expect(TokenType.IDENTIFIER).value
        self.expect(TokenType.RPAREN)
        self.expect(TokenType.COLON)

        # Check for bracket expression: change(x): [ math.sqrt(x) ]
        if self.current().type == TokenType.LBRACKET:
            self.advance()
            expr = self.parse_expression()
            self.expect(TokenType.RBRACKET)
            return ast.ChangeWithExpr(name, expr)

        op_tok = self.match(TokenType.PLUS, TokenType.MINUS, TokenType.STAR, TokenType.SLASH, TokenType.POWER)
        if op_tok:
            value = self.parse_expression()
            # Check for secondary operation: change(x): y / 2
            op2 = self.match(TokenType.PLUS, TokenType.MINUS, TokenType.STAR, TokenType.SLASH, TokenType.POWER)
            if op2:
                val2 = self.parse_expression()
                return ast.ChangeVariable(name, op_tok.value, value, val2)
            return ast.ChangeVariable(name, op_tok.value, value)
        else:
            value = self.parse_expression()
            return ast.ChangeVariable(name, '=', value)

    def parse_change_global(self):
        """Parse: change.global(name):"""
        self.advance()  # change.global
        self.expect(TokenType.LPAREN)
        name = self.expect(TokenType.IDENTIFIER).value
        self.expect(TokenType.RPAREN)
        self.expect(TokenType.COLON)
        return ast.ChangeGlobal(name)

    def parse_change_list(self):
        """Parse: change.list(name): +/- { elements }"""
        self.advance()  # change.list
        self.expect(TokenType.LPAREN)
        name = self.expect(TokenType.IDENTIFIER).value
        self.expect(TokenType.RPAREN)
        self.expect(TokenType.COLON)

        op = self.match(TokenType.PLUS, TokenType.MINUS)
        if not op:
            raise ParseError("Expected + or - in change.list", self.current())

        self.expect(TokenType.LBRACE)
        elements = self.parse_list_elements()
        self.expect(TokenType.RBRACE)
        return ast.ChangeList(name, op.value, elements)

    def parse_give_com(self):
        """Parse: give.com(expr): or give.com(expr);"""
        self.advance()  # give.com
        self.expect(TokenType.LPAREN)
        expr = self.parse_expression()
        self.expect(TokenType.RPAREN)
        self.match(TokenType.COLON)  # colon is optional
        return ast.GiveCom(expr)

    def parse_give_win(self):
        """Parse: give.win(expr): or give.win(expr): + [ options ]"""
        self.advance()  # give.win
        self.expect(TokenType.LPAREN)
        expr = self.parse_expression()
        self.expect(TokenType.RPAREN)
        self.match(TokenType.COLON)  # colon is optional

        options = None
        if self.match(TokenType.PLUS):
            options = self.parse_bracket_options()
        return ast.GiveWin(expr, options)

    def parse_bracket_options(self):
        """Parse [ option1(v); option2(v); ... ] style options."""
        self.expect(TokenType.LBRACKET)
        options = {}
        while self.current().type != TokenType.RBRACKET and not self.at_end():
            name_tok = self.advance()
            name = name_tok.value
            if self.current().type == TokenType.LPAREN:
                self.advance()
                args = []
                while self.current().type != TokenType.RPAREN and not self.at_end():
                    args.append(self.parse_expression())
                    self.match(TokenType.COMMA)
                self.expect(TokenType.RPAREN)
                options[name] = args
            self.match(TokenType.SEMICOLON)
        self.expect(TokenType.RBRACKET)
        return options

    def parse_def(self):
        """Parse function definition:
        def(name): [ add: params ]:
            body
        stop;
        """
        self.advance()  # def
        self.expect(TokenType.LPAREN)
        # Function name can be IDENTIFIER or ADD (since 'add' is also a keyword)
        tok = self.current()
        if tok.type in (TokenType.IDENTIFIER, TokenType.ADD):
            name = self.advance().value
        else:
            name = self.expect(TokenType.IDENTIFIER).value
        self.expect(TokenType.RPAREN)
        self.expect(TokenType.COLON)

        params = []
        # Check for parameter list: [ add: x, y ]:
        if self.current().type == TokenType.LBRACKET:
            self.advance()
            # Match 'add:' keyword - it can be tokenized as ADD or IDENTIFIER
            if self.current().type == TokenType.ADD or (
                self.current().type == TokenType.IDENTIFIER and self.current().value == 'add'
            ):
                self.advance()  # add
                self.expect(TokenType.COLON)
                while self.current().type != TokenType.RBRACKET and not self.at_end():
                    tok = self.current()
                    if tok.type in (TokenType.IDENTIFIER, TokenType.ADD):
                        params.append(self.advance().value)
                    else:
                        params.append(self.expect(TokenType.IDENTIFIER).value)
                    if not self.match(TokenType.COMMA):
                        break
            self.expect(TokenType.RBRACKET)
            self.expect(TokenType.COLON)

        self.skip_semicolons()
        body = self.parse_statements()
        self.expect(TokenType.STOP)
        return ast.FunctionDef(name, params, body)

    def parse_if(self):
        """Parse if/else-if/else statement."""
        self.advance()  # if
        self.expect(TokenType.LPAREN)
        cond_expr = self.parse_expression()
        self.expect(TokenType.RPAREN)
        self.expect(TokenType.COLON)

        # Parse condition comparison
        condition = self.parse_condition(cond_expr)

        self.skip_semicolons()
        body = self.parse_statements(stop_tokens={TokenType.ELSE_IF, TokenType.ELSE, TokenType.STOP})

        elif_clauses = []
        while self.current().type == TokenType.ELSE_IF:
            self.advance()  # else-if
            self.expect(TokenType.LPAREN)
            elif_cond_expr = self.parse_expression()
            self.expect(TokenType.RPAREN)
            self.expect(TokenType.COLON)
            elif_condition = self.parse_condition(elif_cond_expr)
            self.skip_semicolons()
            elif_body = self.parse_statements(stop_tokens={TokenType.ELSE_IF, TokenType.ELSE, TokenType.STOP})
            elif_clauses.append((elif_condition, elif_body))

        else_body = None
        if self.current().type == TokenType.ELSE:
            self.advance()  # else
            self.match(TokenType.COLON)
            self.match(TokenType.SEMICOLON)  # else; is also valid
            self.skip_semicolons()
            else_body = self.parse_statements(stop_tokens={TokenType.STOP})

        self.expect(TokenType.STOP)
        return ast.IfStatement(condition, body, elif_clauses, else_body)

    def parse_condition(self, left_expr):
        """Parse a condition comparison: = value, > value, etc."""
        if self.current().type in (TokenType.EQUALS, TokenType.GREATER, TokenType.GREATER_EQ,
                                    TokenType.LESS, TokenType.LESS_EQ, TokenType.NOT_EQUAL):
            op = self.advance().value
            right = self.parse_expression()
            return ast.Comparison(op, left_expr, right)
        # No comparison operator - treat as truthy check
        return left_expr

    def parse_while(self):
        """Parse while loop: while(cond): = val; body stop;"""
        self.advance()  # while
        self.expect(TokenType.LPAREN)
        cond_expr = self.parse_expression()
        self.expect(TokenType.RPAREN)
        self.expect(TokenType.COLON)

        condition = self.parse_condition(cond_expr)

        self.skip_semicolons()
        body = self.parse_statements()
        self.expect(TokenType.STOP)
        return ast.WhileStatement(condition, body)

    def parse_for(self):
        """Parse for loop: for(x): [start ~ end]; body stop;"""
        self.advance()  # for
        self.expect(TokenType.LPAREN)
        var_name = self.expect(TokenType.IDENTIFIER).value
        self.expect(TokenType.RPAREN)
        self.expect(TokenType.COLON)

        self.expect(TokenType.LBRACKET)
        start = self.parse_expression()
        self.expect(TokenType.TILDE)
        end = self.parse_expression()
        self.expect(TokenType.RBRACKET)

        self.skip_semicolons()
        body = self.parse_statements()
        self.expect(TokenType.STOP)
        return ast.ForStatement(var_name, ast.RangeExpr(start, end), body)

    def parse_return(self):
        """Parse return(value)"""
        self.advance()  # return
        self.expect(TokenType.LPAREN)
        value = self.parse_expression()
        self.expect(TokenType.RPAREN)
        return ast.ReturnStatement(value)

    def parse_global_decl(self):
        """Parse global.name"""
        tok = self.advance()
        name = tok.value.split('.', 1)[1]
        return ast.GlobalDecl(name)

    def parse_function_call_stmt(self):
        """Parse function.name; (as a statement)"""
        tok = self.current()
        if tok.type == TokenType.FUNCTION:
            self.advance()
            name = tok.value.split('.', 1)[1]
            # Check for arguments in parens
            args = []
            if self.current().type == TokenType.LPAREN:
                self.advance()
                while self.current().type != TokenType.RPAREN and not self.at_end():
                    args.append(self.parse_expression())
                    self.match(TokenType.COMMA)
                self.expect(TokenType.RPAREN)
            return ast.FunctionCall(name, args)
        return self.parse_expression_statement()

    def parse_implement(self):
        """Parse implement.module_name;"""
        tok = self.advance()
        name = tok.value.split('.', 1)[1]
        self.match(TokenType.SEMICOLON)
        return ast.ImplementStatement(name)

    def parse_start_programm(self):
        """Parse start.programm( body stop)"""
        self.advance()  # start.programm
        self.expect(TokenType.LPAREN)
        self.skip_semicolons()
        body = self.parse_statements()
        self.expect(TokenType.STOP)
        self.expect(TokenType.RPAREN)
        return ast.StartProgramm(body)

    def parse_make_windows(self):
        """Parse make.windows( settings stop);"""
        self.advance()  # make.windows
        self.expect(TokenType.LPAREN)
        self.skip_semicolons()

        settings = {}
        while self.current().type != TokenType.STOP and not self.at_end():
            tok = self.current()
            if tok.type == TokenType.WINDOWS:
                prop_name = tok.value  # e.g. windows.titel
                self.advance()
                self.expect(TokenType.LPAREN)
                args = []
                while self.current().type != TokenType.RPAREN and not self.at_end():
                    args.append(self.parse_expression())
                    self.match(TokenType.COMMA)
                self.expect(TokenType.RPAREN)
                prop = prop_name.split('.', 1)[1]  # titel, color, size
                settings[prop] = args
            self.skip_semicolons()

        self.expect(TokenType.STOP)
        self.match(TokenType.RPAREN)
        return ast.MakeWindows(settings)

    def parse_depict(self):
        """Parse depict(name): = [ options ]"""
        self.advance()  # depict
        self.expect(TokenType.LPAREN)
        name = self.expect(TokenType.IDENTIFIER).value
        self.expect(TokenType.RPAREN)
        self.expect(TokenType.COLON)
        self.match(TokenType.EQUALS)

        options = self.parse_bracket_options()
        return ast.DepictStatement(name, options)

    def parse_set_color(self):
        """Parse set.color(name): [ r, g, b ] or set.color(name): = [ r, g, b ]"""
        self.advance()  # set.color
        self.expect(TokenType.LPAREN)
        name = self.expect(TokenType.IDENTIFIER).value
        self.expect(TokenType.RPAREN)
        self.expect(TokenType.COLON)
        self.match(TokenType.EQUALS)  # optional = sign
        self.expect(TokenType.LBRACKET)
        r = self.parse_expression()
        self.expect(TokenType.COMMA)
        g = self.parse_expression()
        self.expect(TokenType.COMMA)
        b = self.parse_expression()
        self.expect(TokenType.RBRACKET)
        return ast.SetColorDef(name, [r, g, b])

    def parse_set_texture(self):
        """Parse set.texture(name): [ load_expr ]"""
        self.advance()  # set.texture
        self.expect(TokenType.LPAREN)
        name = self.expect(TokenType.IDENTIFIER).value
        self.expect(TokenType.RPAREN)
        self.expect(TokenType.COLON)
        self.expect(TokenType.LBRACKET)
        expr = self.parse_expression()
        self.expect(TokenType.RBRACKET)
        return ast.SetTexture(name, expr)

    def parse_set_fps(self):
        """Parse set.fps(value):"""
        self.advance()  # set.fps
        self.expect(TokenType.LPAREN)
        value = self.parse_expression()
        self.expect(TokenType.RPAREN)
        self.expect(TokenType.COLON)
        return ast.SetFps(value)

    def parse_load_image(self):
        """Parse load.image(filename):"""
        self.advance()  # load.image
        self.expect(TokenType.LPAREN)
        filename = self.advance().value
        self.expect(TokenType.RPAREN)
        self.match(TokenType.COLON)
        return ast.LoadImage(filename)

    def parse_fill(self):
        """Parse fill(name): = [ color ]"""
        self.advance()  # fill
        self.expect(TokenType.LPAREN)
        name = self.expect(TokenType.IDENTIFIER).value
        self.expect(TokenType.RPAREN)
        self.expect(TokenType.COLON)
        self.match(TokenType.EQUALS)
        self.expect(TokenType.LBRACKET)
        color = self.parse_expression()
        self.expect(TokenType.RBRACKET)
        return ast.FillStatement(name, color)

    def parse_clear(self):
        """Parse clear(target):"""
        self.advance()  # clear
        self.expect(TokenType.LPAREN)
        target = self.advance().value
        self.expect(TokenType.RPAREN)
        self.expect(TokenType.COLON)
        return ast.ClearStatement(target)

    def parse_close(self):
        """Parse close(target):"""
        self.advance()  # close
        self.expect(TokenType.LPAREN)
        target = self.advance().value
        self.expect(TokenType.RPAREN)
        self.expect(TokenType.COLON)
        return ast.CloseStatement(target)

    def parse_class(self):
        """Parse class(name): body stop;"""
        self.advance()  # class
        self.expect(TokenType.LPAREN)
        name = self.expect(TokenType.IDENTIFIER).value
        self.expect(TokenType.RPAREN)
        self.expect(TokenType.COLON)
        self.skip_semicolons()
        body = self.parse_statements()
        self.expect(TokenType.STOP)
        return ast.ClassDef(name, body)

    def parse_expression_statement(self):
        """Parse an expression as a statement (e.g. function call)."""
        expr = self.parse_expression()
        return expr

    # ---- Expression parsing ----

    def parse_expression(self):
        """Parse an expression with logical operators."""
        return self.parse_logical_or()

    def parse_logical_or(self):
        left = self.parse_logical_and()
        while self.current().type == TokenType.OR:
            self.advance()
            right = self.parse_logical_and()
            left = ast.LogicalOp('or', left, right)
        return left

    def parse_logical_and(self):
        left = self.parse_logical_not()
        while self.current().type == TokenType.AND:
            self.advance()
            right = self.parse_logical_not()
            left = ast.LogicalOp('and', left, right)
        return left

    def parse_logical_not(self):
        if self.current().type == TokenType.NOT:
            self.advance()
            operand = self.parse_logical_not()
            return ast.NotOp(operand)
        return self.parse_addition()

    def parse_addition(self):
        left = self.parse_multiplication()
        while self.current().type in (TokenType.PLUS, TokenType.MINUS):
            op = self.advance().value
            right = self.parse_multiplication()
            left = ast.BinaryOp(op, left, right)
        return left

    def parse_multiplication(self):
        left = self.parse_power()
        while self.current().type in (TokenType.STAR, TokenType.SLASH):
            op = self.advance().value
            right = self.parse_power()
            left = ast.BinaryOp(op, left, right)
        return left

    def parse_power(self):
        left = self.parse_unary()
        if self.current().type == TokenType.POWER:
            self.advance()
            right = self.parse_power()  # right-associative
            left = ast.BinaryOp('**', left, right)
        return left

    def parse_unary(self):
        if self.current().type == TokenType.MINUS:
            self.advance()
            operand = self.parse_unary()
            return ast.UnaryOp('-', operand)
        return self.parse_primary()

    def parse_primary(self):
        tok = self.current()

        if tok.type == TokenType.NUMBER:
            self.advance()
            return ast.NumberLiteral(tok.value)

        if tok.type == TokenType.STRING:
            self.advance()
            return self.process_string_interpolation(tok.value)

        if tok.type == TokenType.TRUE:
            self.advance()
            return ast.BooleanLiteral(True)

        if tok.type == TokenType.FALSE:
            self.advance()
            return ast.BooleanLiteral(False)

        if tok.type == TokenType.PRESSED:
            self.advance()
            return ast.StringLiteral("pressed")

        if tok.type == TokenType.IDENTIFIER:
            name = tok.value
            self.advance()

            # Check for module call: random.Number(x), math.sqrt(x) etc
            if '.' in name:
                parts = name.split('.', 1)
                module = parts[0]
                method = parts[1]
                if self.current().type == TokenType.LPAREN:
                    self.advance()
                    args = []
                    while self.current().type != TokenType.RPAREN and not self.at_end():
                        args.append(self.parse_expression())
                        self.match(TokenType.COMMA)
                    self.expect(TokenType.RPAREN)
                    return ast.ModuleCall(module, method, args)
                return ast.ModuleCall(module, method, [])

            # Check for function call with parens
            if self.current().type == TokenType.LPAREN:
                self.advance()
                args = []
                while self.current().type != TokenType.RPAREN and not self.at_end():
                    args.append(self.parse_expression())
                    self.match(TokenType.COMMA)
                self.expect(TokenType.RPAREN)
                return ast.FunctionCall(name, args)

            return ast.Identifier(name)

        if tok.type == TokenType.FUNCTION:
            self.advance()
            name = tok.value.split('.', 1)[1]
            args = []
            if self.current().type == TokenType.LPAREN:
                self.advance()
                while self.current().type != TokenType.RPAREN and not self.at_end():
                    args.append(self.parse_expression())
                    self.match(TokenType.COMMA)
                self.expect(TokenType.RPAREN)
            return ast.FunctionCall(name, args)

        if tok.type == TokenType.KEY:
            self.advance()
            key_name = tok.value.split('.', 1)[1]
            return ast.KeyCheck(key_name)

        if tok.type == TokenType.IDENTIFIER and tok.value == 'next':
            self.advance()
            self.expect(TokenType.LPAREN)
            self.expect(TokenType.INPUT)
            self.expect(TokenType.RPAREN)
            return ast.NextInput()

        if tok.type == TokenType.ROUND:
            self.advance()
            self.expect(TokenType.LPAREN)
            value = self.parse_expression()
            self.expect(TokenType.RPAREN)
            self.match(TokenType.COLON)
            return ast.RoundExpr(value)

        if tok.type == TokenType.ROUND_ON:
            self.advance()
            self.expect(TokenType.LPAREN)
            value = self.parse_expression()
            self.expect(TokenType.RPAREN)
            self.expect(TokenType.COLON)
            self.expect(TokenType.EQUALS)
            decimals = self.parse_expression()
            return ast.RoundOnExpr(value, decimals)

        if tok.type == TokenType.LOAD_IMAGE:
            self.advance()
            self.expect(TokenType.LPAREN)
            filename = self.advance().value
            self.expect(TokenType.RPAREN)
            self.match(TokenType.COLON)
            return ast.LoadImage(filename)

        if tok.type == TokenType.LPAREN:
            self.advance()
            expr = self.parse_expression()
            self.expect(TokenType.RPAREN)
            return expr

        if tok.type == TokenType.LBRACKET:
            self.advance()
            expr = self.parse_expression()
            self.expect(TokenType.RBRACKET)
            return ast.ListBracketExpr(expr)

        # next(input) as expression
        if tok.type == TokenType.IDENTIFIER and tok.value == 'next':
            self.advance()
            if self.match(TokenType.LPAREN):
                self.expect(TokenType.INPUT)
                self.expect(TokenType.RPAREN)
                return ast.NextInput()
            return ast.Identifier('next')

        if tok.type == TokenType.INPUT:
            self.advance()
            return ast.NextInput()

        if tok.type == TokenType.IDENTIFIER and tok.value == 'error':
            self.advance()
            return ast.Identifier('error')

        raise ParseError(f"Unexpected token in expression: {tok.type} ({tok.value!r})", tok)

    def process_string_interpolation(self, s):
        """Process <var> interpolation in strings."""
        parts = []
        i = 0
        current = []
        while i < len(s):
            if s[i] == '<':
                j = s.find('>', i)
                if j != -1:
                    if current:
                        parts.append(''.join(current))
                        current = []
                    var_name = s[i + 1:j]
                    parts.append(ast.Identifier(var_name))
                    i = j + 1
                    continue
            current.append(s[i])
            i += 1
        if current:
            parts.append(''.join(current))

        if len(parts) == 1 and isinstance(parts[0], str):
            return ast.StringLiteral(parts[0])
        if not parts:
            return ast.StringLiteral(s)
        return ast.InterpolatedString(parts)
