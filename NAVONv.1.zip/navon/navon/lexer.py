"""Lexer/Tokenizer for the NAVON programming language."""

from .tokens import Token, TokenType


class LexerError(Exception):
    def __init__(self, message, line, column):
        self.line = line
        self.column = column
        super().__init__(f"Syntax-error at line {line}, column {column}: {message}")


class Lexer:
    def __init__(self, source: str, filename: str = "<stdin>"):
        self.source = source
        self.filename = filename
        self.pos = 0
        self.line = 1
        self.column = 1
        self.tokens = []

    def error(self, msg):
        raise LexerError(msg, self.line, self.column)

    def peek(self, offset=0):
        p = self.pos + offset
        if p < len(self.source):
            return self.source[p]
        return '\0'

    def advance(self):
        ch = self.source[self.pos]
        self.pos += 1
        if ch == '\n':
            self.line += 1
            self.column = 1
        else:
            self.column += 1
        return ch

    def skip_whitespace(self):
        while self.pos < len(self.source) and self.source[self.pos] in (' ', '\t', '\r'):
            self.advance()

    def skip_line_comment(self):
        """Skip ?{ ... } comments."""
        self.advance()  # skip ?
        self.advance()  # skip {
        while self.pos < len(self.source):
            if self.source[self.pos] == '}':
                self.advance()
                return
            self.advance()

    def skip_side_comment(self):
        """Skip ?[ ... ] comments."""
        self.advance()  # skip ?
        self.advance()  # skip [
        while self.pos < len(self.source):
            if self.source[self.pos] == ']':
                self.advance()
                return
            self.advance()

    def skip_multiline_comment(self):
        """Skip ?/ ... / comments."""
        self.advance()  # skip ?
        self.advance()  # skip /
        while self.pos < len(self.source):
            if self.source[self.pos] == '/' and (self.pos + 1 >= len(self.source) or self.source[self.pos + 1] != '/'):
                self.advance()
                return
            self.advance()

    def read_string(self):
        """Read a string literal enclosed in double quotes."""
        line = self.line
        col = self.column
        self.advance()  # skip opening "
        result = []
        while self.pos < len(self.source) and self.source[self.pos] != '"':
            if self.source[self.pos] == '\\':
                self.advance()
                ch = self.advance()
                if ch == 'n':
                    result.append('\n')
                elif ch == 't':
                    result.append('\t')
                elif ch == '"':
                    result.append('"')
                elif ch == '\\':
                    result.append('\\')
                else:
                    result.append(ch)
            else:
                result.append(self.advance())
        if self.pos >= len(self.source):
            self.error("Unterminated string literal")
        self.advance()  # skip closing "
        return Token(TokenType.STRING, ''.join(result), line, col)

    def read_number(self):
        """Read a number (integer or float)."""
        line = self.line
        col = self.column
        result = []
        has_dot = False
        while self.pos < len(self.source) and (self.source[self.pos].isdigit() or self.source[self.pos] in ('.', ',')):
            ch = self.source[self.pos]
            if ch in ('.', ','):
                # Check if it's a decimal separator
                if ch == ',' and self.pos + 1 < len(self.source) and self.source[self.pos + 1].isdigit():
                    # German-style decimal comma
                    if has_dot:
                        break
                    has_dot = True
                    self.advance()
                    result.append('.')
                    continue
                elif ch == '.':
                    # Could be method call - check if next char is digit
                    if self.pos + 1 < len(self.source) and self.source[self.pos + 1].isdigit():
                        if has_dot:
                            break
                        has_dot = True
                        result.append('.')
                        self.advance()
                        continue
                    else:
                        break
                else:
                    break
            result.append(self.advance())
        num_str = ''.join(result)
        if has_dot:
            return Token(TokenType.NUMBER, float(num_str), line, col)
        else:
            return Token(TokenType.NUMBER, int(num_str), line, col)

    def read_identifier(self):
        """Read an identifier or keyword."""
        line = self.line
        col = self.column
        result = []
        while self.pos < len(self.source) and (self.source[self.pos].isalnum() or self.source[self.pos] in ('_', '-')):
            # Handle else-if specially
            if self.source[self.pos] == '-':
                rest = self.source[self.pos:]
                if rest.startswith('-if'):
                    result.append(self.advance())  # -
                    continue
                else:
                    break
            result.append(self.advance())
        word = ''.join(result)
        return self._classify_word(word, line, col)

    def _classify_word(self, word, line, col):
        """Classify an identifier as keyword or plain identifier."""
        keyword_map = {
            'set': TokenType.SET,
            'change': TokenType.CHANGE,
            'def': TokenType.DEF,
            'if': TokenType.IF,
            'else-if': TokenType.ELSE_IF,
            'else': TokenType.ELSE,
            'while': TokenType.WHILE,
            'for': TokenType.FOR,
            'stop': TokenType.STOP,
            'return': TokenType.RETURN,
            'break': TokenType.BREAK,
            'not': TokenType.NOT,
            'and': TokenType.AND,
            'or': TokenType.OR,
            'True': TokenType.TRUE,
            'False': TokenType.FALSE,
            'pressed': TokenType.PRESSED,
            'input': TokenType.INPUT,
            'add': TokenType.ADD,
            'class': TokenType.CLASS,
        }
        tt = keyword_map.get(word)
        if tt:
            return Token(tt, word, line, col)
        return Token(TokenType.IDENTIFIER, word, line, col)

    def read_compound_keyword(self):
        """Read compound keywords like set.list, give.com, etc."""
        line = self.line
        col = self.column
        result = []

        while self.pos < len(self.source) and (self.source[self.pos].isalnum() or self.source[self.pos] in ('_', '-', '.')):
            if self.source[self.pos] == '-':
                rest = self.source[self.pos:]
                if rest.startswith('-if'):
                    result.append(self.advance())
                    continue
                else:
                    break
            if self.source[self.pos] == '.':
                # Look ahead to see if this is part of a compound keyword
                next_start = self.pos + 1
                if next_start < len(self.source) and self.source[next_start].isalpha():
                    result.append(self.advance())  # include the dot
                    continue
                else:
                    break
            result.append(self.advance())

        word = ''.join(result)

        # Special case: if the word is just 'n' and next char is '=', it's the n= operator
        if word == 'n' and self.pos < len(self.source) and self.source[self.pos] == '=':
            self.advance()  # consume '='
            return Token(TokenType.NOT_EQUAL, 'n=', line, col)

        return self._classify_compound(word, line, col)

    def _classify_compound(self, word, line, col):
        """Classify compound keywords."""
        compound_map = {
            'set.list': TokenType.SET_LIST,
            'change.list': TokenType.CHANGE_LIST,
            'change.global': TokenType.CHANGE_GLOBAL,
            'give.com': TokenType.GIVE_COM,
            'give.win': TokenType.GIVE_WIN,
            'start.programm': TokenType.START_PROGRAMM,
            'make.windows': TokenType.MAKE_WINDOWS,
            'windows.titel': TokenType.WINDOWS,
            'windows.color': TokenType.WINDOWS,
            'windows.size': TokenType.WINDOWS,
            'set.color': TokenType.SET_COLOR,
            'set.texture': TokenType.SET_TEXTURE,
            'set.textur': TokenType.SET_TEXTURE,
            'set.sound': TokenType.SET_SOUND,
            'set.video': TokenType.SET_VIDEO,
            'set.fps': TokenType.SET_FPS,
            'load.image': TokenType.LOAD_IMAGE,
            'load.sound': TokenType.LOAD_SOUND,
            'load.video': TokenType.LOAD_VIDEO,
            'collision.only': TokenType.COLLISION_ONLY,
            'round.on': TokenType.ROUND_ON,
            'else-if': TokenType.ELSE_IF,
        }
        tt = compound_map.get(word)
        if tt:
            return Token(tt, word, line, col)

        # Check for global.x, function.x, implement.x, key.x patterns
        if word.startswith('global.'):
            return Token(TokenType.GLOBAL, word, line, col)
        if word.startswith('function.'):
            return Token(TokenType.FUNCTION, word, line, col)
        if word.startswith('implement.'):
            return Token(TokenType.IMPLEMENT, word, line, col)
        if word.startswith('key.'):
            return Token(TokenType.KEY, word, line, col)
        if word.startswith('random.') or word.startswith('json.') or word.startswith('math.'):
            return Token(TokenType.IDENTIFIER, word, line, col)

        # Check single-word keywords
        simple_map = {
            'set': TokenType.SET,
            'change': TokenType.CHANGE,
            'def': TokenType.DEF,
            'if': TokenType.IF,
            'else': TokenType.ELSE,
            'while': TokenType.WHILE,
            'for': TokenType.FOR,
            'stop': TokenType.STOP,
            'return': TokenType.RETURN,
            'break': TokenType.BREAK,
            'not': TokenType.NOT,
            'and': TokenType.AND,
            'or': TokenType.OR,
            'True': TokenType.TRUE,
            'False': TokenType.FALSE,
            'pressed': TokenType.PRESSED,
            'input': TokenType.INPUT,
            'add': TokenType.ADD,
            'class': TokenType.CLASS,
            'depict': TokenType.DEPICT,
            'fill': TokenType.FILL,
            'collision': TokenType.COLLISION,
            'clear': TokenType.CLEAR,
            'close': TokenType.CLOSE,
            'round': TokenType.ROUND,
            'update': TokenType.UPDATE,
            'help': TokenType.HELP,
            'credits': TokenType.CREDITS,
            'exit': TokenType.EXIT,
        }
        tt = simple_map.get(word)
        if tt:
            return Token(tt, word, line, col)

        return Token(TokenType.IDENTIFIER, word, line, col)

    def tokenize(self):
        """Tokenize the entire source code."""
        tokens = []
        while self.pos < len(self.source):
            ch = self.source[self.pos]

            # Whitespace
            if ch in (' ', '\t', '\r'):
                self.skip_whitespace()
                continue

            # Newline
            if ch == '\n':
                tokens.append(Token(TokenType.NEWLINE, '\n', self.line, self.column))
                self.advance()
                continue

            # Comments
            if ch == '?':
                next_ch = self.peek(1)
                if next_ch == '{':
                    self.skip_line_comment()
                    continue
                elif next_ch == '[':
                    self.skip_side_comment()
                    continue
                elif next_ch == '/':
                    self.skip_multiline_comment()
                    continue

            # Inline side comments (= text after a statement on same line)
            # These are handled contextually, not in lexer

            # String literals
            if ch == '"':
                tokens.append(self.read_string())
                continue

            # Numbers
            if ch.isdigit():
                tokens.append(self.read_number())
                continue

            # Identifiers and keywords (including compound ones)
            if ch.isalpha() or ch == '_':
                tokens.append(self.read_compound_keyword())
                continue

            # Operators and delimiters
            line = self.line
            col = self.column

            if ch == '+':
                self.advance()
                tokens.append(Token(TokenType.PLUS, '+', line, col))
            elif ch == '-':
                self.advance()
                tokens.append(Token(TokenType.MINUS, '-', line, col))
            elif ch == '*':
                self.advance()
                if self.pos < len(self.source) and self.source[self.pos] == '*':
                    self.advance()
                    tokens.append(Token(TokenType.POWER, '**', line, col))
                else:
                    tokens.append(Token(TokenType.STAR, '*', line, col))
            elif ch == '/':
                self.advance()
                tokens.append(Token(TokenType.SLASH, '/', line, col))
            elif ch == '=':
                self.advance()
                tokens.append(Token(TokenType.EQUALS, '=', line, col))
            elif ch == '>':
                self.advance()
                if self.pos < len(self.source) and self.source[self.pos] == '=':
                    self.advance()
                    tokens.append(Token(TokenType.GREATER_EQ, '>=', line, col))
                else:
                    tokens.append(Token(TokenType.GREATER, '>', line, col))
            elif ch == '<':
                self.advance()
                if self.pos < len(self.source) and self.source[self.pos] == '=':
                    self.advance()
                    tokens.append(Token(TokenType.LESS_EQ, '<=', line, col))
                else:
                    tokens.append(Token(TokenType.LESS, '<', line, col))
            elif ch == 'n' and self.pos + 1 < len(self.source) and self.source[self.pos + 1] == '=':
                self.advance()
                self.advance()
                tokens.append(Token(TokenType.NOT_EQUAL, 'n=', line, col))
            elif ch == '(':
                self.advance()
                tokens.append(Token(TokenType.LPAREN, '(', line, col))
            elif ch == ')':
                self.advance()
                tokens.append(Token(TokenType.RPAREN, ')', line, col))
            elif ch == '[':
                self.advance()
                tokens.append(Token(TokenType.LBRACKET, '[', line, col))
            elif ch == ']':
                self.advance()
                tokens.append(Token(TokenType.RBRACKET, ']', line, col))
            elif ch == '{':
                self.advance()
                tokens.append(Token(TokenType.LBRACE, '{', line, col))
            elif ch == '}':
                self.advance()
                tokens.append(Token(TokenType.RBRACE, '}', line, col))
            elif ch == ':':
                self.advance()
                tokens.append(Token(TokenType.COLON, ':', line, col))
            elif ch == ';':
                self.advance()
                tokens.append(Token(TokenType.SEMICOLON, ';', line, col))
            elif ch == ',':
                self.advance()
                tokens.append(Token(TokenType.COMMA, ',', line, col))
            elif ch == '~':
                self.advance()
                tokens.append(Token(TokenType.TILDE, '~', line, col))
            elif ch == '.':
                self.advance()
                tokens.append(Token(TokenType.DOT, '.', line, col))
            else:
                self.error(f"Unexpected character: {ch!r}")

        tokens.append(Token(TokenType.EOF, None, self.line, self.column))
        return tokens
