"""AST node definitions for the NAVON programming language."""


class ASTNode:
    pass


class Program(ASTNode):
    def __init__(self, statements):
        self.statements = statements


class NumberLiteral(ASTNode):
    def __init__(self, value):
        self.value = value


class StringLiteral(ASTNode):
    def __init__(self, value):
        self.value = value


class BooleanLiteral(ASTNode):
    def __init__(self, value):
        self.value = value


class Identifier(ASTNode):
    def __init__(self, name):
        self.name = name


class InterpolatedString(ASTNode):
    """String with <var> interpolation."""
    def __init__(self, parts):
        self.parts = parts  # list of (str | Identifier)


class BinaryOp(ASTNode):
    def __init__(self, op, left, right):
        self.op = op
        self.left = left
        self.right = right


class UnaryOp(ASTNode):
    def __init__(self, op, operand):
        self.op = op
        self.operand = operand


class Comparison(ASTNode):
    def __init__(self, op, left, right):
        self.op = op  # '=', '>', '>=', '<', '<=', 'n='
        self.left = left
        self.right = right


class LogicalOp(ASTNode):
    def __init__(self, op, left, right):
        self.op = op  # 'and', 'or'
        self.left = left
        self.right = right


class NotOp(ASTNode):
    def __init__(self, operand):
        self.operand = operand


class SetVariable(ASTNode):
    def __init__(self, name, value):
        self.name = name
        self.value = value


class ChangeVariable(ASTNode):
    def __init__(self, name, op, value, second_value=None):
        self.name = name
        self.op = op        # '+', '-', '*', '/', '**'
        self.value = value
        self.second_value = second_value  # for change(x): y / 2


class ChangeGlobal(ASTNode):
    def __init__(self, name):
        self.name = name


class SetList(ASTNode):
    def __init__(self, name, elements):
        self.name = name
        self.elements = elements  # list of ASTNode or RangeExpr


class RangeExpr(ASTNode):
    def __init__(self, start, end):
        self.start = start
        self.end = end


class ChangeList(ASTNode):
    def __init__(self, name, op, elements):
        self.name = name
        self.op = op  # '+' or '-'
        self.elements = elements


class GiveCom(ASTNode):
    def __init__(self, expr):
        self.expr = expr


class GiveWin(ASTNode):
    def __init__(self, expr, options=None):
        self.expr = expr
        self.options = options  # dict with place, color, size


class FunctionDef(ASTNode):
    def __init__(self, name, params, body):
        self.name = name
        self.params = params  # list of param names
        self.body = body      # list of statements


class FunctionCall(ASTNode):
    def __init__(self, name, args=None):
        self.name = name
        self.args = args or []


class GlobalDecl(ASTNode):
    def __init__(self, name):
        self.name = name


class ReturnStatement(ASTNode):
    def __init__(self, value):
        self.value = value


class BreakStatement(ASTNode):
    pass


class IfStatement(ASTNode):
    def __init__(self, condition, body, elif_clauses=None, else_body=None):
        self.condition = condition
        self.body = body
        self.elif_clauses = elif_clauses or []
        self.else_body = else_body


class WhileStatement(ASTNode):
    def __init__(self, condition, body):
        self.condition = condition
        self.body = body


class ForStatement(ASTNode):
    def __init__(self, var_name, range_expr, body):
        self.var_name = var_name
        self.range_expr = range_expr
        self.body = body


class StartProgramm(ASTNode):
    def __init__(self, body):
        self.body = body


class ImplementStatement(ASTNode):
    def __init__(self, module_name):
        self.module_name = module_name


class MakeWindows(ASTNode):
    def __init__(self, settings):
        self.settings = settings  # dict: titel, color, size


class WindowsSetting(ASTNode):
    def __init__(self, prop, value):
        self.prop = prop
        self.value = value


class CloseStatement(ASTNode):
    def __init__(self, target):
        self.target = target


class DepictStatement(ASTNode):
    def __init__(self, name, options):
        self.name = name
        self.options = options  # dict with state, place, color, size, text, etc.


class SetColorDef(ASTNode):
    def __init__(self, name, rgb):
        self.name = name
        self.rgb = rgb  # list of 3 values


class FillStatement(ASTNode):
    def __init__(self, name, color):
        self.name = name
        self.color = color


class CollisionCheck(ASTNode):
    def __init__(self, name, only_with=None):
        self.name = name
        self.only_with = only_with


class ClearStatement(ASTNode):
    def __init__(self, target):
        self.target = target


class NextInput(ASTNode):
    pass


class RoundExpr(ASTNode):
    def __init__(self, value):
        self.value = value


class RoundOnExpr(ASTNode):
    def __init__(self, value, decimals):
        self.value = value
        self.decimals = decimals


class ClassDef(ASTNode):
    def __init__(self, name, body):
        self.name = name
        self.body = body


class SetFps(ASTNode):
    def __init__(self, value):
        self.value = value


class LoadImage(ASTNode):
    def __init__(self, filename):
        self.filename = filename


class LoadSound(ASTNode):
    def __init__(self, filename):
        self.filename = filename


class LoadVideo(ASTNode):
    def __init__(self, filename):
        self.filename = filename


class SetTexture(ASTNode):
    def __init__(self, name, load_expr):
        self.name = name
        self.load_expr = load_expr


class SetSoundVar(ASTNode):
    def __init__(self, name, load_expr):
        self.name = name
        self.load_expr = load_expr


class UpdateDef(ASTNode):
    def __init__(self):
        pass


class KeyCheck(ASTNode):
    def __init__(self, key_name):
        self.key_name = key_name


class ErrorCheck(ASTNode):
    def __init__(self, body):
        self.body = body


class ModuleCall(ASTNode):
    """Call to a module function like random.Number(x), math.sqrt(x), etc."""
    def __init__(self, module, method, args=None):
        self.module = module
        self.method = method
        self.args = args or []


class ListBracketExpr(ASTNode):
    """Expression wrapped in [ ] for function calls, etc."""
    def __init__(self, expr):
        self.expr = expr


class ChangeWithExpr(ASTNode):
    """change(x): [ expr ] - change with a complex expression in brackets."""
    def __init__(self, name, expr):
        self.name = name
        self.expr = expr
