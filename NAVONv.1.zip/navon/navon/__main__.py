"""Main entry point for the NAVON programming language."""

import sys
import os
from .lexer import Lexer, LexerError
from .parser import Parser, ParseError
from .interpreter import Interpreter
from .errors import NavonError


def run_file(filepath):
    """Run a .nvn file."""
    if not os.path.exists(filepath):
        print(f"File-error: File '{filepath}' not found")
        sys.exit(1)

    with open(filepath, 'r', encoding='utf-8') as f:
        source = f.read()

    filename = os.path.basename(filepath)

    print(f">>> Welcome to NAVON.")
    # Show implemented modules
    try:
        lexer = Lexer(source, filename)
        tokens = lexer.tokenize()
        parser = Parser(tokens, filename)
        program = parser.parse()

        # Collect implement statements for display
        from . import ast_nodes as ast
        impls = []
        for stmt in program.statements:
            if isinstance(stmt, ast.ImplementStatement):
                impls.append(stmt.module_name)
        if impls:
            print(f"impl( {', '.join(impls)} )")

        interpreter = Interpreter(filename)
        interpreter.run(program)
    except (LexerError, ParseError) as e:
        print(f"\n{e}")
        sys.exit(1)
    except NavonError as e:
        print(str(e))
        sys.exit(1)
    except KeyboardInterrupt:
        print("\n>>> Program interrupted.")
        sys.exit(0)


def main():
    if len(sys.argv) > 1:
        filepath = sys.argv[1]
        if filepath.endswith('.nvn'):
            run_file(filepath)
        else:
            print(f"Error: Expected a .nvn file, got '{filepath}'")
            sys.exit(1)
    else:
        from .repl import run_repl
        run_repl()


if __name__ == '__main__':
    main()
