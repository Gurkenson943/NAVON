"""REPL (Read-Eval-Print Loop) for the NAVON programming language."""

import sys
from .lexer import Lexer, LexerError
from .parser import Parser, ParseError
from .interpreter import Interpreter
from .errors import NavonError


BANNER = r""">>> Welcome to NAVON REPL. write: 
help(true): to get help, credits(true): to see the credits, exit(true): to exit
  _____     _____      __   ___          ___  _____  _____     _____ 
  |   |\    |   |     /  \  \  \        /  / / ___ \ |   |\    |   | 
  |   |\\   |   |    / /\ \  \  \      /  /  | | | | |   |\\   |   |
  |   | \\  |   |   / /__\ \  \  \    /  /   | | | | |   | \\  |   |
  |   |  \\ |   |  / ______ \  \  \  /  /    | |_| | |   |  \\ |   |
  |   |   \\|   | / /      \ \  \  \/  /     \     / |   |   \\|   |
<====================================================================>"""

HELP_TEXT = """
=== NAVON Syntax Help ===

--- Variables ---
  set(x): 1           Set x to 1
  set(x): "Hello"     Set x to string "Hello"
  change(x): + 1      Add 1 to x
  change(x): - y      Subtract y from x
  change.global(x):   Make x global

--- Lists ---
  set.list(x): { 1, 2, 3 }    Create list
  set.list(x): { 1, 2 ~ 4 }   Create list with range
  change.list(x): + { 3, 4 }  Add to list
  change.list(x): - { y }     Remove from list

--- Output ---
  give.com(x):           Print x to console
  give.com("text"):      Print text string
  give.com("x = <x>"):   String interpolation
  give.win(x):           Print to window

--- Functions ---
  def(name): [ add: x, y ]:
      return(x + y);
  stop;

  set(z): [ function.name(2, 3) ];
  global.name;           Make function global

--- Control Flow ---
  if(x): = 1;           If x equals 1
  else-if(x): = 2;      Else if x equals 2
  else;                  Otherwise
  stop;

  while(x): = 2;        While x equals 2
      ...
  stop;

  for(x): [1 ~ 10];     For x from 1 to 10
      give.com(x);
  stop;

--- Operators ---
  +    Plus
  -    Minus
  *    Multiply
  /    Divide
  **   Power
  =    Equals
  >    Greater than
  >=   Greater or equal
  <    Less than
  <=   Less or equal
  n=   Not equal

--- Modules ---
  implement.random;     Import random module
  implement.json;       Import JSON module
  implement.math;       Import math module

--- Input ---
  set(x): [ next(input) ];   Read user input

--- Program Entry ---
  start.programm(
      ...
  stop)

--- Notes ---
  End each line with ;
  ?{ Comment }     Block comment
  ?[ Comment ]     Side comment
  ?/ Multi-line
     comment /
"""


def run_repl():
    """Start the NAVON REPL."""
    print(BANNER)
    interpreter = Interpreter("<repl>")

    # Pre-load standard modules
    from .builtins_modules import NavonRandom, NavonJSON, NavonMath
    interpreter.modules['random'] = NavonRandom()
    interpreter.modules['json'] = NavonJSON()
    interpreter.modules['math'] = NavonMath()

    buffer = []
    open_parens = 0
    open_braces = 0

    while True:
        try:
            if buffer:
                prompt = "...> "
            else:
                prompt = "nvn> "

            line = input(prompt)

            # Check for special REPL commands
            stripped = line.strip()
            if not buffer:
                if stripped == 'help(true):' or stripped == 'help(true)':
                    print(HELP_TEXT)
                    continue
                if stripped == 'credits(true):' or stripped == 'credits(true)':
                    print(">>> Build by Paul Kaschnitz from PK-Studios")
                    continue
                if stripped == 'exit(true):' or stripped == 'exit(true)':
                    print(">>> You're exiting now NAVON. BYE BYE")
                    sys.exit(0)

            buffer.append(line)
            full_source = '\n'.join(buffer)

            # Count open parens/braces to handle multi-line input
            open_parens += line.count('(') - line.count(')')
            open_braces += line.count('{') - line.count('}')

            # Check if we need more input
            if open_parens > 0 or open_braces > 0:
                continue

            # Check if line ends with : or open paren (need more input)
            if stripped.endswith(':') and not stripped.endswith('stop'):
                continue

            # Check for stop keyword to know when block is done
            if any(kw in full_source for kw in ['def(', 'if(', 'while(', 'for(', 'start.programm(']):
                if 'stop' not in full_source:
                    continue

            # Try to parse and execute
            try:
                lexer = Lexer(full_source, "<repl>")
                tokens = lexer.tokenize()
                parser = Parser(tokens, "<repl>")
                program = parser.parse()
                interpreter.run(program)
            except (LexerError, ParseError) as e:
                print(f"\n{e}")
            except NavonError as e:
                print(str(e))
            except Exception as e:
                print(f"\nIntern-error: {e}")

            buffer = []
            open_parens = 0
            open_braces = 0

        except KeyboardInterrupt:
            print("\n>>> You're exiting now NAVON. BYE BYE")
            sys.exit(0)
        except EOFError:
            print("\n>>> You're exiting now NAVON. BYE BYE")
            sys.exit(0)
