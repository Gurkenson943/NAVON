"""Tests for the NAVON programming language interpreter."""

import sys
import os
import io
from contextlib import redirect_stdout

# Add parent dir so we can import navon
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from navon.lexer import Lexer
from navon.parser import Parser
from navon.interpreter import Interpreter
from navon.errors import NavonError, DivisionByZeroError_, FuncError_


def run_navon(source, filename="<test>"):
    """Helper: run NAVON source and capture stdout."""
    lexer = Lexer(source, filename)
    tokens = lexer.tokenize()
    parser = Parser(tokens, filename)
    program = parser.parse()
    interpreter = Interpreter(filename)
    buf = io.StringIO()
    with redirect_stdout(buf):
        interpreter.run(program)
    return buf.getvalue().strip(), interpreter


def test_hello_world():
    output, _ = run_navon('''
start.programm(
    give.com("Hallo Welt!");
stop)
''')
    assert output == "Hallo Welt!", f"Expected 'Hallo Welt!', got '{output}'"


def test_variables():
    output, _ = run_navon('''
start.programm(
    set(x): 10;
    give.com(x);
stop)
''')
    assert output == "10", f"Expected '10', got '{output}'"


def test_string_variable():
    output, _ = run_navon('''
start.programm(
    set(name): "World";
    give.com("Hello <name>");
stop)
''')
    assert output == "Hello World", f"Expected 'Hello World', got '{output}'"


def test_change_variable():
    output, _ = run_navon('''
start.programm(
    set(x): 5;
    change(x): + 3;
    give.com(x);
stop)
''')
    assert output == "8", f"Expected '8', got '{output}'"


def test_change_multiply():
    output, _ = run_navon('''
start.programm(
    set(x): 4;
    change(x): * 3;
    give.com(x);
stop)
''')
    assert output == "12", f"Expected '12', got '{output}'"


def test_arithmetic_expression():
    output, _ = run_navon('''
start.programm(
    give.com(2 + 3);
stop)
''')
    assert output == "5", f"Expected '5', got '{output}'"


def test_function_definition_and_call():
    output, _ = run_navon('''
def(add): [ add: x, y ]:
    return(x + y);
stop;

start.programm(
    set(z): [ function.add(2, 3) ];
    give.com(z);
stop)
''')
    assert output == "5", f"Expected '5', got '{output}'"


def test_if_statement():
    output, _ = run_navon('''
start.programm(
    set(x): 2;
    if(x): = 2;
        give.com("x ist gleich 2");
    else;
        give.com("x ist nicht 2");
    stop;
stop)
''')
    assert output == "x ist gleich 2", f"Got '{output}'"


def test_if_else():
    output, _ = run_navon('''
start.programm(
    set(x): 5;
    if(x): = 2;
        give.com("zwei");
    else;
        give.com("nicht zwei");
    stop;
stop)
''')
    assert output == "nicht zwei", f"Got '{output}'"


def test_for_loop():
    output, _ = run_navon('''
start.programm(
    for(i): [1 ~ 5];
        give.com(i);
    stop;
stop)
''')
    lines = output.split('\n')
    assert lines == ['1', '2', '3', '4', '5'], f"Got {lines}"


def test_while_loop():
    output, _ = run_navon('''
start.programm(
    set(x): 0;
    while(x): < 3;
        change(x): + 1;
        give.com(x);
    stop;
stop)
''')
    lines = output.split('\n')
    assert lines == ['1', '2', '3'], f"Got {lines}"


def test_global_function():
    output, _ = run_navon('''
def(inc):
    change(x): + 1;
    give.com(x);
stop;

global.inc;

start.programm(
    set(x): 1;
    function.inc;
stop)
''')
    assert output == "2", f"Expected '2', got '{output}'"


def test_math_module():
    output, _ = run_navon('''
implement.math;

start.programm(
    set(x): 25;
    change(x): [ math.sqrt(x) ];
    give.com(x);
stop)
''')
    assert output == "5", f"Expected '5', got '{output}'"


def test_math_pi():
    output, _ = run_navon('''
implement.math;

start.programm(
    set(x): [ math.pi ];
    give.com(x);
stop)
''')
    assert output.startswith("3.14159"), f"Expected pi, got '{output}'"


def test_list_operations():
    output, _ = run_navon('''
start.programm(
    set.list(x): { 1, 2, 3 };
    give.com(x);
stop)
''')
    assert output == "[1, 2, 3]", f"Got '{output}'"


def test_list_add():
    output, _ = run_navon('''
start.programm(
    set.list(x): { 1, 2 };
    change.list(x): + { 3, 4 };
    give.com(x);
stop)
''')
    assert output == "[1, 2, 3, 4]", f"Got '{output}'"


def test_list_remove():
    output, _ = run_navon('''
start.programm(
    set.list(x): { 1, 2, 3 };
    change.list(x): - { 2 };
    give.com(x);
stop)
''')
    assert output == "[1, 3]", f"Got '{output}'"


def test_string_interpolation():
    output, _ = run_navon('''
start.programm(
    set(age): 20;
    give.com("Du bist <age> Jahre alt");
stop)
''')
    assert output == "Du bist 20 Jahre alt", f"Got '{output}'"


def test_random_seed():
    output, _ = run_navon('''
implement.random;

start.programm(
    set(x): [ random.seed(3) ];
    give.com(x);
stop)
''')
    assert len(output) == 3, f"Expected 3-digit code, got '{output}'"
    assert output.isdigit(), f"Expected digits, got '{output}'"


def test_comparison_operators():
    output, _ = run_navon('''
start.programm(
    set(x): 5;
    if(x): > 3;
        give.com("groesser");
    stop;
stop)
''')
    assert output == "groesser", f"Got '{output}'"


def test_not_equal():
    output, _ = run_navon('''
start.programm(
    set(x): 3;
    if(x): n= 5;
        give.com("nicht gleich");
    stop;
stop)
''')
    assert output == "nicht gleich", f"Got '{output}'"


def test_division_by_zero():
    try:
        run_navon('''
start.programm(
    set(x): 10;
    change(x): / 0;
stop)
''')
        assert False, "Should have raised DivisionByZeroError_"
    except DivisionByZeroError_:
        pass


def test_undefined_variable():
    try:
        run_navon('''
start.programm(
    give.com(undefined_var);
stop)
''')
        assert False, "Should have raised FuncError_"
    except FuncError_:
        pass


def test_comments():
    output, _ = run_navon('''
?{ This is a block comment }
start.programm(
    give.com("OK"); ?[ side comment ]
stop)
''')
    assert output == "OK", f"Got '{output}'"


def test_power_operator():
    output, _ = run_navon('''
start.programm(
    set(x): 2;
    change(x): ** 3;
    give.com(x);
stop)
''')
    assert output == "8", f"Expected '8', got '{output}'"


def test_round_expression():
    output, _ = run_navon('''
implement.math;

start.programm(
    set(x): 3.7;
    change(x): [ round(x) ];
    give.com(x);
stop)
''')
    assert output == "4", f"Expected '4', got '{output}'"


def test_implement_statement():
    output, _ = run_navon('''
implement.math;
implement.random;

start.programm(
    give.com("OK");
stop)
''')
    assert output == "OK"


def test_nested_if():
    output, _ = run_navon('''
start.programm(
    set(x): 5;
    set(y): 10;
    if(x): = 5;
        if(y): = 10;
            give.com("both");
        stop;
    stop;
stop)
''')
    assert output == "both", f"Got '{output}'"


if __name__ == '__main__':
    tests = [
        test_hello_world,
        test_variables,
        test_string_variable,
        test_change_variable,
        test_change_multiply,
        test_arithmetic_expression,
        test_function_definition_and_call,
        test_if_statement,
        test_if_else,
        test_for_loop,
        test_while_loop,
        test_global_function,
        test_math_module,
        test_math_pi,
        test_list_operations,
        test_list_add,
        test_list_remove,
        test_string_interpolation,
        test_random_seed,
        test_comparison_operators,
        test_not_equal,
        test_division_by_zero,
        test_undefined_variable,
        test_comments,
        test_power_operator,
        test_round_expression,
        test_implement_statement,
        test_nested_if,
    ]

    passed = 0
    failed = 0
    for test in tests:
        try:
            test()
            print(f"  PASS: {test.__name__}")
            passed += 1
        except Exception as e:
            print(f"  FAIL: {test.__name__}: {e}")
            failed += 1

    print(f"\n{passed} passed, {failed} failed out of {len(tests)} tests")
    sys.exit(1 if failed > 0 else 0)
